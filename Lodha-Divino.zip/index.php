<?php
include_once __DIR__ . "/config.php";
include_once "nitropack-sdk/bootstrap.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-M6TRGXWV');
    </script>
  <!-- <link rel="icon" href="./images/project-logo.webp" sizes="16x16" /> -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <title>Luxury 2, 3 & 4 BHK Flats in Matunga – Lodha Divino | Premium Living</title>
  <meta name="description" content="Discover Lodha Divino in Matunga East: 2,3 & 4 BHK luxury flats with sundecks, club house, landscaped gardens & top schools nearby. Ready for call-backs & inquiries." />
    
  <meta name="keywords" content="Aaradhya Avaan, Lodha Aaradhya Avaan, luxury residences Tardeo, 3 BHK South Mumbai, 4 BHK South Mumbai, thoughtfully designed apartments, world-class amenities, panoramic city views, Lodha premium homes, elevating everyday living" />

<link rel="icon" type="image/png" href="images/favicon.png">
  <link rel="canonical" href="index-2.html" />
  <meta name="robots" content="index, follow" />
  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <link rel="stylesheet" href="css/all.min.css" />
  <link rel="stylesheet" href="css/owl.carousel.css" />
  <link rel="stylesheet" href="css/owl.theme.default.css" />
  <link rel="stylesheet" href="css/slick-theme.css" />
  <link rel="stylesheet" href="css/slick.css" />
 
  <link rel="stylesheet" href="css/slick-lightbox.css" />
  <link rel="stylesheet" href="css/gallery.css" />
  <link href="css/styles.css" rel="stylesheet" />
    <link href="css/main.css" rel="stylesheet" />

  <link href="css/theme.css" rel="stylesheet" />
  <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/css/intlTelInput.css" />

  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11368350367"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11368350367');
</script>

 <style>
      /* Show desktop banner by default */
.banner-desktop {
  display: block;
}
.banner-mobile {
  display: none;
}

@media (max-width: 768px) {
  .banner-desktop {
    display: none;
  }
  .banner-mobile {
    display: block;
  }
}

  </style>
</head>
<body class="tvs-green">
   <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M6TRGXWV"
        height="0" width="0" style="display:none;visibility:hidden">
   </iframe></noscript>
   <!-- xxxxxxxxxxxx Navigator  xxxxxxxxxxxx -->
   <nav class="navbar navbar-expand-lg navbar-light fixed-top" >
      <div class="container-fluid">
         <a class="navbar-brand" >

            <img src="images/logo.png" class="img-fluid" alt="Logo" style="height:100%;" />
          </a>

          
         <div class="d-flex">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
               aria-controls="navbarNav">
            <span class="navbar-toggler-icon"></span>
            </button>
         </div>
         <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
            <ul class="navbar-nav align-items-center">
               <li class="nav-item">
                  <a class="nav-link" href="#top-section">Home</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#overview">Overview</a>
               </li>
              <li class="nav-item">
                  <a class="nav-link" href="#amenities">Amenities</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#pricing"> Pricings </a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#floorplan"> Floor Plan</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link ml-3" href="#gallery">Gallery</a>
               </li>
                <li class="nav-item">
                  <a class="nav-link ml-3" href="#whyus">Social</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#connectivity">Location</a>
               </li>
               
            </ul>
         </div>
      </div>
   </nav>
   
   
   <!--Qr code  details -->
   <!-- Button -->


   <!-- xxxxxxxxxxxx Navigator End xxxxxxxxxxxx -->
   <div class="main-container d-flex">
      <main class="left-section">
             <section id="top-section">
              <!-- Desktop Banner -->
              <img class="banner-desktop  w-100" src="images/banners/bg1.jpg" alt="Desktop Banner" />
            
              <!-- Mobile Banner -->
              <img class="banner-mobile  w-100" src="images/banners/bg3.jpg" alt="Mobile Banner" />
            </section>

       
         <div class="page-wrapper">
  
            <div class="mob-form d-sm-block d-md-none d-lg-none d-none">
               <div class="call-back-section text-center pt-3 pb-3" style="border-bottom: 1px solid #ddd">
                  <h3 class="mb-0">Pre-Register here for Best Offers</h3>
               </div>
               <div class="form-section p-4">
                  <div class="row">
                     <div class="form_inner" id=" ">
                        <input type="text" name="name" class="form-control" placeholder="Name" id="qSenderName" />
                           <small class="error-message text-danger"></small>

                        <input type="text" name="Mobile No." class="form-control phone-input" placeholder="Mobile No"
                           id="qMobileNo" />
                              <small class="error-message text-danger"></small>

                        <input type="email" name="email" class="form-control" placeholder="E-Mail Address" id="qEmailID" />
                           <small class="error-message text-danger"></small>

                        <input class="form-control" type="text" placeholder="Comments.." name="Message" id="qMessage" />
                           <small class="error-message text-danger"></small>
                        <input type="hidden" name="utm_source" value="" />
                        <input type="hidden" name="utm_campaign" value="" />
                        <div class="captcha-wrapper">
                            <span class="captchaQuestion"></span>
                            <input type="text" class="captchaAnswer form-control" placeholder="Enter answer" />
                            <small class="error-message text-danger"></small>
                        </div>
                        



                        <button type="button" class="btn btn-warning enquire-btn effetMoveGradient effectScale btn1"
                           id="SubmitQuery">
                        Enquire Now
                        </button>
                        <div class="checkbox-section">
                           <input type="checkbox" name="" value="" checked="" />
                           <p>
                              I authorize company representatives to Call, SMS, Email or
                              WhatsApp me about its products and offers. This consent
                              overrides any registration for DNC/NDNC
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
       
            <section  id="overview">
               <div class="container">
                  <div class="row">
                     <div class="col-xl-7 col-lg-7 col-sm-12">
                        <div class="overview-data">
                           <h1 style="font-size:3rem;font-weight: 300;color:#9d7f19">Discover Lavish Living at Matunga’s New Landmark</h1>
                           <p class="overview-info" style="color:black;">
                            Welcome to Lodha Divino, where every corner of this expansive green sanctuary is designed to ignite passions and enrich lifestyles – be it sport, leisure, or celebration. Thoughtfully crafted lavish luxury apartments in Mumbai by renowned builders and developers Kapadia Associates and landscapes by Sitetectonix, Singapore, is set to transform the way Matunga lives, forever! <br><br>
                                Choose from spacious 2BHK, 3BHK and 4BHK Flats with smart layouts in Mumbai offering minimal passage wastage, full-height windows, and lavish sundecks framing the stunning views of the Arabian Sea and lush gardens. Along with a massive central lawn, green promenades, and tree-lined open spaces, our residents no longer need to visit Five Gardens – as they already have their own.

                           </p>
                           <button id="request-brochure-button" type="button"
                              class="download-brochure custom-btn btn-block data-id-btn" data-bs-target="#enquire-modal"
                              data-bs-toggle="modal" data-bs-whatever="Request Brochure" data-id="Brochure">
                           <img src="images/icons/brouchre.png" class="fa-download" />
                           Request Brochure
                           </button>
                          
                        </div>
                     </div>
                     <div class="col-xl-5 col-lg-5 col-sm-12 text-center ps-0 pe-0">
                        <img src="images/lodha_divino-matunga-mumbai-lodha_group.avif" width="100%" height="520px" class="data-id-btn" data-id="Project Video"
                           alt="lodha" style="border-radius: 5px;" />
                     </div>
                  </div>
<div class="row g-3 pt-3 mt-2" id="gap1" style="justify-content: center; gap: 20px;">
    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/icon2.svg" alt="Residences" style="width: 50px;height: 50px;">
            </div>
            <h4 class="feature-title">Opulent 2, 3, and 4 BHK Residences with Study</h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/building.svg" alt="Towers" >
            </div>
            <h4 class="feature-title">Iconic 38-Storey Towers</h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/view.svg" alt="Panoramic Views" style="width: 50px;height: 50px;">
            </div>
            <h4 class="feature-title">Homes with open decks and panoramic views</h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/room.svg" alt="Open Spaces">
            </div>
            <h4 class="feature-title">Large open spaces with picnic spots, lifestyle cabanas, and rich greenery</h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/cctv.svg" alt="Security">
            </div>
            <h4 class="feature-title">State-of-the-art security and seamless, high-end services</h4>
        </div>
    </div>
</div>






               </div>
            </section>
            <!-- xxxxxxxxxxxx Overview section End  xxxxxxxxxxxx -->
            <!-- xxxxxxxxxxxx Highlight section  xxxxxxxxxxxx -->
            
            <section id="amenities" class="micl-section" >
  <div class="micl-container">
    <div class="micl-header">
      <h2 class="micl-title" style="font-size:3rem;font-weight:300;color:#9d7f19">
        Amenities & Experiences
      </h2>
    </div>

    <div class="micl-cards-grid">
      <div class="micl-card">
  <img src="images/icons/a1.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
          Lavish Clubhouse with Café, Gymnasium, and Indoor Games (table tennis, snooker, chess, carrom)
        </div>
      </div>

      <div class="micl-card">
<img src="images/icons/a2.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
<div class="micl-card-description">Elegant Guest Rooms to host your visitors</div>
      </div>

      <div class="micl-card">
        <img src="images/icons/a3.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">Party Hall and Celebration Lawn for unforgettable gatherings</div>
      </div>

      <div class="micl-card">
        <img src="images/icons/a4.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">Outdoor Cinema experience under the stars</div>
      </div>

      <div class="micl-card">
<img src="images/icons/a5.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">Adventure Play Village & Toddler Play Area for endless fun and learning
</div>
      </div>

      <div class="micl-card">
        <img src="images/icons/a6.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">Luxury Swimming Pools with dedicated zones for adults and children
</div>
      </div>

      <div class="micl-card">
        <img src="images/icons/a7.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
          World-Class Sports Facilities: Cricket Pitch, Futsal Court, Basketball & Badminton Courts
        </div>
      </div>

      <div class="micl-card">
        <img src="images/icons/a8.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
          Outdoor Gym, Chess Garden, Spectator Seating
        </div>
      </div>

      <div class="micl-card">
       <img src="images/icons/a9.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
          Lifestyle Cabanas with work-from-home setups amidst nature
        </div>
      </div>

      <div class="micl-card">
        <img src="images/icons/a10.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
          High-Street Retail Boulevard, shop for premium brands within the estate
        </div>
      </div>

      <div class="micl-card">
        <img src="images/icons/a11.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
         Multi-Purpose Lawn, Picnic Plaza & Landscaped Terrace for leisure and community bonding
        </div>
      </div>

      <div class="micl-card">
        <img src="images/icons/a12.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">>
        <div class="micl-card-description">
          Jain temple offering spiritual sanctuary
        </div>
      </div>
    </div>
  </div>
</section>

    <!-- xxxxxxxxxxxx floor plan  xxxxxxxxxxxx -->
    
    <section id="pricing" style="margin-bottom: 10px;">
        
        
          <div class="floorplan-main-container">
        <div class="floorplan-wrapper">
            <!-- Configuration Section -->
       <!-- Additional Pricing Information -->
                <div class="floorplan-pricing-section">
                    <h4 class="floorplan-pricing-title" style="font-size: 2.5rem;font-weight: 300;text-align: center;color: #9d7f19;">Configuration</h4>
                    
                    <div class="floorplan-pricing-row floorplan-pricing-header">
                        <span>Configuration</span>
                        <span>Price (INR)</span>
                    </div>
                                            
                    <div class="floorplan-pricing-row">
                        <span class="floorplan-pricing-cell">2 BHK Flat in Matunga East</span>
                        <span class="floorplan-price-value">Starting ₹8.99 Cr</span>
                    </div>
                    
                    <div class="floorplan-pricing-row">
                        <span class="floorplan-pricing-cell">3 BHK Flats in Matunga</span>
                        <span class="floorplan-price-value">Starting ₹12 Cr</span>
                    </div>
                    <div class="floorplan-pricing-row">
                        <span class="floorplan-pricing-cell">4 BHK Flats in South Mumbai</span>
                        <span class="floorplan-price-value">On Request</span>
                    </div>
                    
                 
   
                </div>
            <!-- Floor Plan Section -->
            <div id="floorplan" class="floorplan-visual-section">
                <div class="floorplan-visual-header">
                    <h4 class="floorplan-pricing-title" style="font-size: 2.5rem;font-weight: 300;text-align: center;color: #9d7f19;">Floor Plan</h4>
                </div>
                

               <div class="floorplan-image-container">
                    <div class="floorplan-image-slider">
                        <div class="floorplan-slide fp-active">
                            <img src="images/floor-plan/map1.jpg" alt="Floor Plan 1" class="floorplan-img">
                                <button class="overlay-btn" data-bs-toggle="modal" data-bs-target="#enquire-modal">Enquire Now</button>
                        </div>
                        <div class="floorplan-slide">
                            <img src="images/floor-plan/map2.jpg" alt="Floor Plan 2" class="floorplan-img">
                                <button class="overlay-btn" data-bs-toggle="modal" data-bs-target="#enquire-modal">Enquire Now</button>

                        </div>
                        <div class="floorplan-slide">
                            <img src="images/floor-plan/map3.jpg" alt="Floor Plan 2" class="floorplan-img">
                                <button class="overlay-btn" data-bs-toggle="modal" data-bs-target="#enquire-modal">Enquire Now</button>

                        </div>
                        <div class="floorplan-slide">
                            <img src="images/floor-plan/map4.jpg" alt="Floor Plan 2" class="floorplan-img">
                                <button class="overlay-btn" data-bs-toggle="modal" data-bs-target="#enquire-modal">Enquire Now</button>

                        </div>
                        <div class="floorplan-slide">
                            <img src="images/floor-plan/map5.jpg" alt="Floor Plan 2" class="floorplan-img">
                                <button class="overlay-btn" data-bs-toggle="modal" data-bs-target="#enquire-modal">Enquire Now</button>

                        </div>
                    </div>
                
                    <button class="floorplan-nav-btn floorplan-prev-btn" onclick="fpPrevSlide()">‹</button>
                    <button class="floorplan-nav-btn floorplan-next-btn" onclick="fpNextSlide()">›</button>
                </div>

            </div>
        </div>
    </div>
    </section>
    
    
<section id="section-built" class="section overflow-visible section-built">
  <div class="built-detail">
    <div class="built-img" style="margin: 0 10px;">
           <video class="d-block w-100" autoplay muted loop >
  <source src="images/gallery/g20.mp4" type="video/mp4">
</video> 
    </div>
  </div>
</section>
<!-- xxxxxxxxxxxx floor plan end xxxxxxxxxxxx -->


            <!-- xxxxxxxxxxxx Gallery section  xxxxxxxxxxxx -->
            <section id="gallery">
               <div class="container wow fadeInUp">
                  <!-- data-wow-delay="0.1s" -->
                  <h1 class="text-center color-imp" style="font-size:3rem;font-weight: 300;color:#9d7f19">Project Gallery</h1>
                  <div class="content-gallery">
                     <div class="gallery js-gallery">
                               <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/g10.jpg" alt="" class="gallery-img" />
                           </div>
                        </div>
                         <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/g11.jpg" alt="" class="gallery-img" />
                           </div>
                        </div>
                       <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/temple.jpeg" alt="" class="gallery-img" />
                           </div>
                        </div>
                      
                     
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/g15.jpg" alt="" class="gallery-img" />
                           </div>
                        </div>
                        
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/g16.jpg" alt="" class="gallery-img" />
                           </div>
                        </div>
                        
                        
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/g18.jpg" alt="" class="gallery-img" />
                           </div>
                        </div>
                         <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/g19.jpg" alt="" class="gallery-img" />
                           </div>
                        </div>
                         <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/g21.jpg" alt="" class="gallery-img" />
                           </div>
                        </div>
                    
                        
                
                       
                     </div>
                  </div>
               </div>
            </section>


    <section id="whyus" class="micl-section">
        <div class="micl-container">
            <div class="micl-header">
                <h2 class="micl-title" style="font-size:3rem;font-weight: 300;color:#9d7f19">Sustainability & Social Initiatives</h2>
            </div>
            
<div class="micl-cards-grid">
  <div class="micl-card">
  <img src="images/icons/earth.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
    <div class="micl-card-description">
      Committed to achieve Net Zero carbon emissions by 2035
    </div>
  </div>

  <div class="micl-card">
  <img src="images/icons/water.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
    <div class="micl-card-description">
      100% wastewater recycling for sustainable living
    </div>
  </div>

  <div class="micl-card">
  <img src="images/icons/tree.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
    <div class="micl-card-description">
      Green power initiative with increased on-site tree cover
    </div>
  </div>


</div><div class="micl-cards-grid second-row" style="justify-items: center;">
        <div class="micl-card" style="
        margin-right: 1%;">
  <img src="images/icons/skill.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
          Empowering women through skill development by Lodha Foundation
        </div>
      </div>
    
        <div class="micl-card" style="margin-left: 1%;">
  <img src="images/icons/house.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
          Dedicated social housing for economically weaker sections
        </div>
      </div>
</div>

        </div>
    </section>


<section id="connectivity">
  <div class="container">
    <h2 class="text-left color-imp mb-4" style="font-size:3rem;font-weight:300;text-align:center;color:#9d7f19;">
      Location Advantage
    </h2>

    <div class="row pt-30">
      <!-- Left side content -->
      <div class="col-xl-6 col-lg-6 col-sm-12 text-dark">
        <h3 style="font-size:1.8rem; font-weight:400; margin-bottom:15px;">Explore the neighbourhood</h3>
        <p style="font-size:1rem; line-height:1.6;">
                The serene neighbourhood of Matunga comes with the fresh air of Five Gardens, quaint cafés, renowned educational institutions, and calming temples to connect with your inner self. But also keeps you connected to the vibrant business and entertainment hubs of the city, with Lodha Divino having easy access to Old Matunga and the Eastern Express Highway.
        </p>

       <ul style="list-style:none; padding:0; margin-top:20px;">
          <li style="margin-bottom:10px; display:flex; align-items:center;">
            <img src="images/icons/m1.webp" alt="BKC" width="20" height="20" style="margin-right:8px;">
            <strong>BKC</strong> – 15 minutes
          </li>
          <li style="margin-bottom:10px; display:flex; align-items:center;">
            <img src="images/icons//m2.webp" alt="Lower Parel" width="20" height="20" style="margin-right:8px;">
            <strong>Lower Parel</strong> – 20 minutes
          </li>
          <li style="margin-bottom:10px; display:flex; align-items:center;">
            <img src="images/icons//m3.webp" alt="Five Gardens" width="20" height="20" style="margin-right:8px;">
            <strong>Five Gardens</strong> – 5 minutes
          </li>
          <li style="margin-bottom:10px; display:flex; align-items:center;">
            <img src="images/icons//m4.webp" alt="Eastern Express Highway" width="20" height="20" style="margin-right:8px;">
            <strong>Eastern Express Highway</strong> – 01 minute
          </li>
          <li style="margin-bottom:10px; display:flex; align-items:center;">
            <img src="images/icons//m5.webp" alt="Little Angel’s school" width="20" height="20" style="margin-right:8px;">
            <strong>Little Angel’s School</strong> – a short walk
          </li>
          <li style="margin-bottom:10px; display:flex; align-items:center;">
            <img src="images/icons//m5.webp" alt="Shishuvan School & Don Bosco International School" width="20" height="20" style="margin-right:8px;">
            <strong>Shishuvan School & Don Bosco International School</strong>
          </li>
        </ul>


        <p style="font-size:0.9rem; color:#555; margin-top:10px;">
          <em>Note: All distances stated in minutes are estimated travel time on 2-wheelers during normal traffic.</em>
        </p>
      </div>

      <!-- Right side map -->
      <div class="col-xl-6 col-lg-6 col-sm-11 text-dark pt-2 amenities-img">
        <img src="images/location5.png" class="img-fluid data-id-btn"
          style="cursor:pointer; border:1px solid #25252560;"
          alt="Location Map"
          data-bs-target="#enquire-modal"
          data-bs-toggle="modal"
          data-bs-whatever="Request Location Details"
          data-id="Request Location" />
      </div>
    </div>
     <div id="btnmap" style="display:flex; justify-content:center; margin-top:20px;">
          <button style="width: 170px;" id="request-brochure-button" type="button"
            class="download-brochure custom-btn btn-block data-id-btn"
            data-bs-target="#enquire-modal"
            data-bs-toggle="modal"
            data-bs-whatever="Request Brochure"
            data-id="Brochure">
            <a style="color:white; text-decoration:none;" data-bs-target="#enquire-modal">
              Get Direction
            </a>
          </button>
        </div>
  </div>
</section>




            <section id="contact">
               <div class="container-fluid full-width"></div>
               <div class="container">
                  <div class="contact-inner">
                     <div class="container contact-data">
                        <div class="row">
                           <div class="col-lx-6 col-lg-6 col-sm-12 image-carousel1 ps-0 pe-0">
                              <div class="contact-video" id="vidcontainer">
                                 <img src="images/gallery/gallery5.jpg" width="100%" />
                              </div>
                           </div>
                           <div class="col-lx-6 col-lg-6 col-sm-12 form-data">
                              <h2 class="text-left ms-3 mt-3" style="font-size: 30px;color:#9d7f19;">
                                 Schedule a Site Visit
                              </h2>
                              <div class="form">
                                 <div class="row">
                                    <div class="form_inner" id="form1">
                                          <div class="form-message" style="display:none; color:green; font-weight:bold; margin-bottom:10px;"></div>
                                       <input type="text" name="name" class="form-control" placeholder="Name" id="qSenderName1" />
                                          <small class="error-message text-danger"></small>

                                       <input type="text" name="Mobile No." class="form-control phone-input" placeholder="Mobile No" id="qMobileNo1" />
                                          <small class="error-message text-danger"></small>

                                       <input type="email" name="email" class="form-control" placeholder="E-Mail Address" id="qEmailID1" />
                                          <small class="error-message text-danger"></small>
                                        <select name="configuration" class="form-control" id="qConfiguration1">
                                           <option value="">Select Configuration</option>
                                           <option value="2 BHK Flat in Matunga East @Starting ₹8.99 Cr">2 BHK Flat in Matunga East(Starting ₹8.99 Cr)</option>
                                            <option value="3 BHK Flats in Matunga @Starting ₹12 Cr">3 BHK Flats in Matunga(Starting ₹12 Cr)</option>
                                            <option value="4 BHK Flats in South Mumbai @ On Request">4 BHK Flats in South Mumbai(On Request)</option>

                                         </select>
                                         <input type="hidden" name="utm_source" value="" />
                                        <input type="hidden" name="utm_campaign" value="" />
                                        <div class="captcha-wrapper">
                                            <span class="captchaQuestion"></span>
                                            <input type="text" class="captchaAnswer form-control" placeholder="Enter answer" />
                                            <small class="error-message text-danger"></small>
                                        </div>


                                       <button type="button" class="btn btn-warning enquire-btn effetMoveGradient effectScale" id="SubmitQuery1">
                                       Enquire Now
                                       </button>
                                       <div class="checkbox-section">
                                          <input type="checkbox" name="" value="" checked="" />
                                          <p> I authorize company representatives to Call, SMS, Email or WhatsApp me about its products and offers. This consent overrides any registration
                                             for DNC/NDNC </p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lx-6 col-lg-6 col-sm-12 ps-0 pe-0 image-carousel m-0">
                              <!-- -->
                              <div class="contact-video">
                                 <!-- contact-video-overlay-->
                                 <img src="images/gallery/gallery1.jpg" width="100%" />
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>

            <footer>
               <div class="container">
                
                  <p><b>Project Rera No.</b>P51900048675</p>
                  <p id="disclaimer"> Disclaimer: The content provided on this website is for information purposes only and does not constitute an offer to avail any service. The prices mentioned are subject to change without prior notice, and the availability of properties mentioned is not guaranteed. The images displayed on the website are for representation purposes only and may not reflect the actual properties accurately. Please note that this is the official website of an authorized marketing partner. We may share data with Real Estate Regulatory Authority (RERA) registered brokers/companies for further processing as required. We may also send updates and information to the mobile number or email ID registered with us. All rights reserved. The content, design, and information on this website are protected by copyright and other intellectual property rights. Any unauthorized use or reproduction of the content may violate applicable laws. For accurate and up-to-date information regarding services, pricing, availability, and any other details, it is advisable to contact us directly through the provided contact information on this website. Thank you for visiting our website.
                  </p>
                  <p style="margin: 0px;padding-bottom: 2%;padding-top: 2%;">
                     <a href="disclaimer.html" target="_blank" style="color: #000">Disclaimer | Privacy Policy
                     </a>
                  </p>
                 
               </div>
            </footer>
            <section>
               <div class="footer-enquiryBtn d-flex d-sm-none">
                  <a class="monCall data-id-btn" id="mobPhone" href="tel:+919137829957"><em class="fa fa-phone"></em> Call</a>
                  <a id="discovery_mobile" target="_blank" class="monCall whatsappBtn data-id-btn" href="https://api.whatsapp.com/send?phone=+919137829957%20%20&amp;text=Hello,%20Looking%20for%20Lodha-Divino%20Matunga-East%20At%20Mumbai.%20Get%20in%20touch%20with%20me%20my%20name%20is"><i class="fa fa-brands fa-WhatsApp"></i>
                  WhatsApp</a>
                  <a class="monCall data-id-btn" id="mobPhone" data-bs-target="#enquire-modal" data-bs-toggle="modal"
                     data-bs-whatever="Enquire Now" data-id="Enquire Now">Enquire Now</a>
               </div>
            </section>
         </div>
      </main>
      <section class="desktop-summary">
         <div class="og-block d-flex justify-content-between">
            <button id="right-panel-schedule-site-visit-button" class="btn data-id-btn" data-bs-target="#enquire-modal"
               data-bs-toggle="modal" data-bs-whatever="Book A Site Visit" data-id="Site Visit">
            Schedule Site Visit
            </button>
            <button class="btn"><em class="fa fa-phone"></em><a href="tel:919137829957"
               style="color:#ffff;text-decoration:none;"> +91-9137829957</a> </button>
         </div>
         <div class="form-section p-3">
            <h2 class="pb-2" style="color: #9d7f19;text-align: center; font-weight:300;" >Pre-Register here for Best Offers</h2>
            <div class="row">
               <div class="form_inner" id="form2">
                     <div class="form-message" style="display:none; color:green; font-weight:bold; margin-bottom:10px;"></div>
                  <input type="text" name="name" class="form-control" placeholder="Name" id="qSenderName2" />
                     <small class="error-message text-danger"></small>
                  <input type="text" name="Mobile No." class="form-control phone-input" placeholder="Mobile No"
                     id="qMobileNo2" />
                        <small class="error-message text-danger"></small>
                  <input type="email" name="email" class="form-control" placeholder="E-Mail Address" id="qEmailID2" />
                     <small class="error-message text-danger"></small>
                  <select name="configuration" class="form-control" id="qConfiguration2">
                        <option value="">Select Configuration</option>
                       <option value="2 BHK Flat in Matunga East @Starting ₹8.99 Cr">2 BHK Flat in Matunga East(Starting ₹8.99 Cr)</option>
                                            <option value="3 BHK Flats in Matunga @Starting ₹12 Cr">3 BHK Flats in Matunga(Starting ₹12 Cr)</option>
                                            <option value="4 BHK Flats in South Mumbai @ On Request">4 BHK Flats in South Mumbai(On Request)</option>

                  </select>
                  <input type="hidden" name="utm_source" value="" />
                        <input type="hidden" name="utm_campaign" value="" />
                    <div class="captcha-wrapper">
                        <span class="captchaQuestion"></span>
                        <input type="text" class="captchaAnswer form-control" placeholder="Enter answer" />
                        <small class="error-message text-danger"></small>
                    </div>



                        
                  <button type="button" class="btn btn-warning enquire-btn effetMoveGradient effectScale btn1"
                     id="SubmitQuery2">
                  Enquire Now
                  </button>
                  <div class="checkbox-section">
                     <input type="checkbox" name="" value="" checked="" />
                     <p>
                        I authorize company representatives to Call, SMS, Email or WhatsApp me about its products and offers. This consent overrides any registration for DNC/NDNC
                     </p>
                  </div>
               </div>
            </div>

         </div>
         <!--end form-section-->
       
         <!--end call-back-section-->
      </section>
   </div>

   <div class="modal enquire-modal" data-bs-dismissable="modal" id="enquire-modal">
      <div class="modal-dialog">
         <div class="popup-images-offer">
            <!-- <div class="left-sec">
               <img src="images/SHIVAM DSK. POP UP.jpg" class="img-fluid d_sm_none">
               <img src="images/SHIVAM DSK.jpg" class="img-fluid d_sm_block">
            </div> -->
            <div class="right-sec w-100">
               <div class="modal-content" id="form3">
                  <div class="modal-header">
                     <h4 class="modal-title text-center">Enquire Now</h4>
                     <button type="button" class="btn btn-md close modal-close" data-bs-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">×</span>
                     </button>
                  </div>
                  <div class="modal-body">
                     <div class="row">
                        <h4 class="text-center" style="color: #9d7f19;">Request a call back</h4>
                         <div class="form-message" style="display:none; color:green; font-weight:bold; margin-bottom:10px;"></div>
                        <div class="form_inner">
                           <input type="text" name="name" class="form-control" placeholder="Name" id="qSenderName3" />
                                                <small class="error-message text-danger"></small>

                           <input type="text" name="Mobile No." class="form-control phone-input" placeholder="Mobile No"
                           
                              id="qMobileNo3" />
                                                   <small class="error-message text-danger"></small>

                           <input type="email" name="email" class="form-control" placeholder="E-Mail Address" id="qEmailID3" />
                                                <small class="error-message text-danger"></small>

                            <select name="configuration" class="form-control" id="qConfiguration3">
                                <option value="">Select Configuration</option>
                               <option value="2 BHK Flat in Matunga East @Starting ₹8.99 Cr">2 BHK Flat in Matunga East(Starting ₹8.99 Cr)</option>
                                            <option value="3 BHK Flats in Matunga @Starting ₹12 Cr">3 BHK Flats in Matunga(Starting ₹12 Cr)</option>
                                            <option value="4 BHK Flats in South Mumbai @ On Request">4 BHK Flats in South Mumbai(On Request)</option>

                             </select>
                           <input type="hidden" name="utm_source" value="" />
                        <input type="hidden" name="utm_campaign" value="" />
                           <div class="captcha-wrapper">
                                <span class="captchaQuestion"></span>
                                <input type="text" class="captchaAnswer form-control" placeholder="Enter answer" />
                                <small class="error-message text-danger"></small>
                            </div>


                           <button type="button" class="btn btn-warning enquire-btn effetMoveGradient effectScale" id="SubmitQuery3">
                           Enquire Now
                           </button>
                           <div class="checkbox-section">
                              <input type="checkbox" name="" value="" checked="" />
                              <p>
                                 I authorize company representatives to Call, SMS, Email or WhatsApp me about its products and offers. This consent overrides any registration for DNC/NDNC
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
<script>
document.addEventListener("DOMContentLoaded", function () {
    let btn = document.getElementById("right-panel-schedule-site-visit-button");
    let modalEl = document.getElementById("enquire-modal");
    let reopenScheduled = false;

    // First auto-click after 5s
    setTimeout(() => {
        if (btn) {
            btn.click();
            console.log("Modal opened by auto-click after 5s");
        }
    }, 5000);

    // When modal is closed → reopen after 25s (only once)
    modalEl.addEventListener("hidden.bs.modal", function () {
        if (!reopenScheduled) {
            reopenScheduled = true;
            setTimeout(() => {
                if (btn) {
                    btn.click();
                    console.log("Modal reopened by auto-click after 25s");
                }
            }, 25000);
        }
    });
});
</script>




<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>



  <script src="js/jquery.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.min.js"></script>
  <!-- gallery JS -->
  <script src="js/slick.min.js"></script>
  <script src="js/slick-lightbox.min.js"></script>
  <script src="js/custom.js"></script>
    <script src="js/main.js"></script>



<script src="https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/intlTelInput.min.js"></script>





</body>


</html>




