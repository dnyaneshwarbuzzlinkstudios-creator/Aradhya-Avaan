<?php
define("NITROPACK_HOME_URL", "https://matunga-divino.com");
define("NITROPACK_SITE_ID", "aEyxWZOPOUtTBYlPwDeaJuHHbgngKXaT");
define("NITROPACK_SITE_SECRET", "RWWjcNbHTAgiVJDh6XNtjLzda8KumVvy2uhLUyUQoAFZLEYXfVEtHTmJajVGPtTp");
