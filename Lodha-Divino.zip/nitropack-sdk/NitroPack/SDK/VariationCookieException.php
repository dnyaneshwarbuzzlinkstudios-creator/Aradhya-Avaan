<?php
namespace NitroPack\SDK;

class VariationCookieException extends \Exception {}
