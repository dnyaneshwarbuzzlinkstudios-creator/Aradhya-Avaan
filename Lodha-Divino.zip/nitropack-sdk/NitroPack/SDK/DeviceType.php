<?php
namespace NitroPack\SDK;

class DeviceType {
    const DESKTOP = "desktop";
    const TABLET  = "tablet";
    const MOBILE  = "mobile";
}
