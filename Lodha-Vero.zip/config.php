<?php
define("NITROPACK_HOME_URL", "https://matunga-vero.co");
define("NITROPACK_SITE_ID", "IPbbqIOfJtpBFUDrhkuHeBsydXUjdRNi");
define("NITROPACK_SITE_SECRET", "TLtb7ISy6SqhyLURuLpw8Y5uaEJg1FihzwsQsH37e5bjcxgnMPx5Zf1ruTD324cT");
