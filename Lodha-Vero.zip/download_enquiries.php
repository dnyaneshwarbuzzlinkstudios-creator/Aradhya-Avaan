<?php
$host = "localhost"; 
$user = "u581629189_dny";
$pass = "Dpawar@123"; 
$db   = "u581629189_avaan";

$conn = new mysqli($host, $user, $pass, $db);
if($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all enquiries (without id)
$sql = "SELECT name, mobile, email, message, created_at FROM enquiries ORDER BY created_at DESC";
$result = $conn->query($sql);

// Set CSV headers
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=enquiries.csv');

// Open output buffer
$output = fopen('php://output', 'w');

// Column headings
fputcsv($output, ['Name', 'Mobile', 'Email', 'Message', 'Created At']);

// Data rows
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()){
        fputcsv($output, $row);
    }
}

fclose($output);
$conn->close();
exit;
?>
