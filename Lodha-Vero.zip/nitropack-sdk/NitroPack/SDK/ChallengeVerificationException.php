<?php
namespace NitroPack\SDK;

class ChallengeVerificationException extends \Exception {}
