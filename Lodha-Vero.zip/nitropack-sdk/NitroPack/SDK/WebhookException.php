<?php
namespace NitroPack\SDK;

class WebhookException extends \Exception {}
