<?php 
include_once __DIR__ . "/config.php";
include_once "nitropack-sdk/bootstrap.php";
?>


<!DOCTYPE html>
<html lang="en">
<head>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N5NV59RD');</script>
  <!-- <link rel="icon" href="./images/project-logo.webp" sizes="16x16" /> -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <title>Lodha Vero Matunga | 3 & 4 BHK Sky Mansions with Private Elevators</title>
  <meta name="description" content="Experience Lodha Vero, Matunga – exclusive 3 & 4 BHK Art Deco sky mansions with private elevators, lavish decks & world-class amenities. Enquire now!" />
    
  <meta name="keywords" content="Aaradhya Avaan, Lodha Aaradhya Avaan, luxury residences Tardeo, 3 BHK South Mumbai, 4 BHK South Mumbai, thoughtfully designed apartments, world-class amenities, panoramic city views, Lodha premium homes, elevating everyday living" />

<link rel="icon" type="image/png" href="images/favicon-lodha.png">
  <link rel="canonical" href="index-2.html" />
  <meta name="robots" content="index, follow" />
  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <link rel="stylesheet" href="css/all.min.css" />
  <link rel="stylesheet" href="css/owl.carousel.css" />
  <link rel="stylesheet" href="css/owl.theme.default.css" />
  <link rel="stylesheet" href="css/slick-theme.css" />
  <link rel="stylesheet" href="css/slick.css" />
  <link rel="stylesheet" href="css/slick-lightbox.css" />
  <link rel="stylesheet" href="css/gallery.css" />
  <link href="css/styles.css" rel="stylesheet" />
    <link href="css/main.css" rel="stylesheet" />

  <link href="css/theme.css" rel="stylesheet" />
  <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/css/intlTelInput.css" />

  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11368350367"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11368350367');
</script>
</head>
<body class="tvs-green">
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N5NV59RD"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
   <!-- xxxxxxxxxxxx Navigator  xxxxxxxxxxxx -->
   <nav class="navbar navbar-expand-lg navbar-light fixed-top" >
      <div class="container-fluid">
         <a class="navbar-brand" >
                         <img src="images/logonew.png" class="img-fluid" alt="Logo" style="height:100%;" />

            <img src="images/vero.png" class="img-fluid" alt="Logo" />
          </a>

          
         <div class="d-flex">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
               aria-controls="navbarNav">
            <span class="navbar-toggler-icon"></span>
            </button>
         </div>
         <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
            <ul class="navbar-nav align-items-center">
               <li class="nav-item">
                  <a class="nav-link" href="#top-section">Home</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#overview">Overview</a>
               </li>
              <li class="nav-item">
                  <a class="nav-link" href="#amenities">Amenities</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#pricing"> Pricing</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#floorplan"> Floor Plan</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link ml-3" href="#gallery">Gallery</a>
               </li>
               <!-- <li class="nav-item">-->
               <!--   <a class="nav-link ml-3" href="#whyus">Social</a>-->
               <!--</li>-->
               <li class="nav-item">
                  <a class="nav-link" href="#connectivity">Location</a>
               </li>
               
            </ul>
         </div>
      </div>
   </nav>
   
   
   <!--Qr code  details -->
   <!-- Button -->


   <!-- xxxxxxxxxxxx Navigator End xxxxxxxxxxxx -->
   <div class="main-container d-flex">
      <main class="left-section">
             <section id="top-section">
       <img id="banner23" class="d-block w-100" src="images/banner.jpg" alt="Banner 2" width="100%"
                                  />
   </section>
         <div class="page-wrapper">
  
            <div class="mob-form d-sm-block d-md-none d-lg-none d-none">
               <div class="call-back-section text-center pt-3 pb-3" style="border-bottom: 1px solid #ddd">
                  <h3 class="mb-0">Pre-Register here for Best Offers</h3>
               </div>
               <div class="form-section p-4">
                  <div class="row">
                     <div class="form_inner" id=" ">
                        <input type="text" name="name" class="form-control" placeholder="Name" id="qSenderName" />
                           <small class="error-message text-danger"></small>

                        <input type="text" name="Mobile No." class="form-control phone-input" placeholder="Mobile No"
                           id="qMobileNo" />
                              <small class="error-message text-danger"></small>

                        <input type="email" name="email" class="form-control" placeholder="E-Mail Address" id="qEmailID" />
                           <small class="error-message text-danger"></small>

                        <input class="form-control" type="text" placeholder="Comments.." name="Message" id="qMessage" />
                           <small class="error-message text-danger"></small>
                           <input type="hidden" name="utm_source" value="" />
                            <input type="hidden" name="utm_campaign" value="" />

                        <div class="captcha-wrapper">
                            <span class="captchaQuestion"></span>
                            <input type="text" class="captchaAnswer form-control" placeholder="Enter answer" />
                            <small class="error-message text-danger"></small>
                        </div>



                        <button type="button" class="btn btn-warning enquire-btn effetMoveGradient effectScale btn1"
                           id="SubmitQuery">
                        Enquire Now
                        </button>
                        <div class="checkbox-section">
                           <input type="checkbox" name="" value="" checked="" />
                           <p>
                              I authorize company representatives to Call, SMS, Email or
                              WhatsApp me about its products and offers. This consent
                              overrides any registration for DNC/NDNC
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
       
            <section  id="overview">
               <div class="container">
                  <div class="row">
                     <div class="col-xl-7 col-lg-7 col-sm-12">
                        <div class="overview-data">
                           <h1 style="font-size:3rem;font-weight: 300;color:#000">Challenge the Usual. Experience the Extraordinary</h1>
                           <p class="overview-info" style="color:black;">
                              Redefining luxury and space, Lodha Vero presents limited edition 3BHK and 4BHK sky mansions in Matunga. These extra-spacious luxury apartments in Mumbai come with your own private elevator and expansive decks that open to breathtaking views of lush city gardens and the Arabian Sea beyond.<br/><br/>
                                Planned and designed by internationally acclaimed Studio HBA and landscaped by Sitetectonix, Singapore, the architecture with its grand facades, harmonious circulation, dynamic outdoor spaces, and world-class amenities offers homeowners and investors a lifestyle where privacy, exclusivity, and luxury converge.
                           </p>
                           <button id="request-brochure-button" type="button"
                              class="download-brochure custom-btn btn-block data-id-btn" data-bs-target="#enquire-modal"
                              data-bs-toggle="modal" data-bs-whatever="Request Brochure" data-id="Brochure">
                           <img src="images/icons/brouchre.png" class="fa-download" />
                           Request Brochure
                           </button>
                          
                        </div>
                     </div>
                     <div class="col-xl-5 col-lg-5 col-sm-12 text-center ps-0 pe-0">
                        <img src="images/g17.jpg" width="100%" height="100%" class="data-id-btn" data-id="Project Video"
                           alt="lodha" style="border-radius: 5px;" />
                     </div>
                  </div>
                  
<div class="row g-3 pt-3 mt-2" id="gap1" style="justify-content: center; gap: 20px;">
    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/building.svg" alt="Residences" >
            </div>
            <h4 class="feature-title">Private elevators for every residence.</h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/icon2.svg" alt="Towers" >
            </div>
            <h4 class="feature-title">Expansive 3BHk and 4BHK living spaces. </h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/a10.png" alt="Panoramic Views">
            </div>
            <h4 class="feature-title">Ultra-private, limited edition luxury residences</h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/icon5.svg" alt="Open Spaces">
            </div>
            <h4 class="feature-title">Lavish decks with panoramic views of city skyline and the Arabian sea</h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/a5.png" alt="Security">
            </div><h4 class="feature-title">Residences designed for luxury living and practical elegance</h4>
        </div>
    </div>
</div>






               </div>
            </section>
            <!-- xxxxxxxxxxxx Overview section End  xxxxxxxxxxxx -->
            
                
    <!--image  banner  Slider -->
    <section>
        
            <!-- New Unique Slick Slider -->
    <div class="custom-slick-slider" style="padding: 0px 10px;">
      <div><img src="images/banners/b1.jpg" alt="Slide 1"></div>
      <div><img src="images/banners/b2.jpg" alt="Slide 2"></div>
      <div><img src="images/temple.jpeg" alt="Slide 4"></div>
      <div><img src="images/banners/b3.jpg" alt="Slide 3"></div>
      <div><img src="images/banners/b4.jpg" alt="Slide 4"></div>
      <div><img src="images/banners/b6.jpg" alt="Slide 4"></div>
    </div>

    </section>
            <!-- xxxxxxxxxxxx Highlight section  xxxxxxxxxxxx -->
            
            <section id="amenities" class="micl-section" >
  <div class="micl-container">
    <div class="micl-header">
      <h2 class="micl-title" style="font-size:3rem;font-weight:300;color:#000">
        Amenities & Experiences
      </h2>
    </div>

    <div class="micl-cards-grid">
      <div class="micl-card">
  <img src="images/entrace.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
          Designer entrance lobby
        </div>
      </div>

      <div class="micl-card">
<img src="images/swim.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
<div class="micl-card-description">Temperature-controlled swimming pool</div>
      </div>

      <div class="micl-card">
        <img src="images/cafe.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">Lounge-café with Alfresco terrace</div>
      </div>


      <div class="micl-card">
<img src="images/gym.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">State-of-the-art gymnasium</div>
      </div>

      <div class="micl-card">
        <img src="images/walk.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">Walking track</div>
      </div>

      <div class="micl-card">
        <img src="images/chess.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
          Indoor games:table tennis,carrom & chess
        </div>
      </div>

      <div class="micl-card">
        <img src="images/party.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
          Party hall
        </div>
      </div>

      <div class="micl-card">
       <img src="images/child.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
          Sports lawn & Children’s play area
        </div>
      </div>
      
      <div class="micl-card">
        <img src="images/a12.png" alt="Building Icon" width="50" height="50" style="margin-bottom: 5%;">
        <div class="micl-card-description">
         Jain Temple
        </div>
      </div>
    </div>
  </div>
</section>


    <!-- xxxxxxxxxxxx floor plan  xxxxxxxxxxxx -->
    
    <section id="pricing" style="margin-bottom: 10px;">
        
        
          <div class="floorplan-main-container">
        <div class="floorplan-wrapper">
            <!-- Configuration Section -->
       <!-- Additional Pricing Information -->
                <div class="floorplan-pricing-section">
                    <h4 class="floorplan-pricing-title" style="font-size: 3rem;font-weight: 300;text-align: center;color: #000;">Configuration</h4>
                    
                    <div class="floorplan-pricing-row floorplan-pricing-header">
                        <span>Configuration</span>
                        <span>Price (INR)</span>
                    </div>
                     
                    <div class="floorplan-pricing-row">
                        <span class="floorplan-pricing-cell">3 BHK Flats in Matunga East</span>
                        <span class="floorplan-price-value">On Request</span>
                    </div>
                    <div class="floorplan-pricing-row">
                        <span class="floorplan-pricing-cell">4 BHK Flats in Matunga</span>
                        <span class="floorplan-price-value">On Request</span>
                    </div>
                   
                </div>
            <!-- Floor Plan Section -->
            <div id="floorplan" class="floorplan-visual-section">
                <div class="floorplan-visual-header">
                    <h4 class="floorplan-pricing-title" style="font-size: 3rem;font-weight: 300;text-align: center;">Floor Plan</h4>
                </div>
                

               <div class="floorplan-image-container">
                    <div class="floorplan-image-slider">
                        <div class="floorplan-slide fp-active">
                            <img src="images/map1.jpg" alt="Floor Plan 1" class="floorplan-img">
                                <button class="overlay-btn" data-bs-toggle="modal" data-bs-target="#enquire-modal">Enquire Now</button>
                        </div>
                        <div class="floorplan-slide">
                            <img src="images/map2.jpg" alt="Floor Plan 2" class="floorplan-img">
                                <button class="overlay-btn" data-bs-toggle="modal" data-bs-target="#enquire-modal">Enquire Now</button>

                        </div>
                        <div class="floorplan-slide">
                            <img src="images/map3.jpg" alt="Floor Plan 2" class="floorplan-img">
                                <button class="overlay-btn" data-bs-toggle="modal" data-bs-target="#enquire-modal">Enquire Now</button>

                        </div>
                        <div class="floorplan-slide">
                            <img src="images/map4.jpg" alt="Floor Plan 2" class="floorplan-img">
                                <button class="overlay-btn" data-bs-toggle="modal" data-bs-target="#enquire-modal">Enquire Now</button>

                        </div>
                    </div>
                
                    <button class="floorplan-nav-btn floorplan-prev-btn" onclick="fpPrevSlide()">‹</button>
                    <button class="floorplan-nav-btn floorplan-next-btn" onclick="fpNextSlide()">›</button>
                </div>

            </div>
        </div>
    </div>
    </section>

<section id="section-built" class="section overflow-visible section-built">
  <div class="built-detail">
    <!--<div class="built-img" style="margin: 0 10px;">-->
     
    <!--<img class="d-block w-100" src="images/gallery3.webp" style="height: 80vh;">-->

    <!--</div>-->
  </div>
</section>
<!-- xxxxxxxxxxxx floor plan end xxxxxxxxxxxx -->


            <!-- xxxxxxxxxxxx Gallery section  xxxxxxxxxxxx -->
            <section id="gallery">
               <div class="container wow fadeInUp">
                  <!-- data-wow-delay="0.1s" -->
                  <h1 class="text-center color-imp" style="font-size:3rem;font-weight: 300;color:#000">Project Gallery</h1>
                  <div class="content-gallery">
                     <div class="gallery js-gallery">
                               <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery1.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                         <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/g17.jpg" alt="" class="gallery-img" />
                           </div>
                        </div>
                         <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery3.jpg" alt="" class="gallery-img" />
                           </div>
                        </div>
                      
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery4.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery5.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery6.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                        
                       
                        
                
                       
                     </div>
                  </div>
               </div>
            </section>



<section id="connectivity">
  <div class="container">
    <h2 class="text-left color-imp mb-4" style="font-size:3rem;font-weight:300;text-align:center;color:#000;">
      Location Advantages
    </h2>

    <div class="row pt-30">
      <!-- Left side content -->
      <div class="col-xl-6 col-lg-6 col-sm-12 text-dark">
        <h3 style="font-size:1.8rem; font-weight:400; margin-bottom:15px; color:#000 !Important;">Explore the neighbourhood</h3>
        <p style="font-size:1rem; line-height:1.6;">
                Whether it’s location or culture, Matunga is the centre of the city. It’s heritage is second to none in the city. Lodha Vero will revive the best of Matunga’s golden era, revisiting its the opulent facades and grand entrances. It will be a landmark for the neighbourhood, and the city overall.
        </p>

       <ul style="list-style:none; padding:0; margin-top:20px;">
          <li style="margin-bottom:10px; display:flex; align-items:center;">
            <img src="images/icons/m1.webp" alt="BKC" width="20" height="20" style="margin-right:8px;">
            15 mins to BKC
          </li>
           <li style="margin-bottom:10px; display:flex; align-items:center;">
            <img src="images/icons//m2.webp" alt="Shishuvan School & Don Bosco International School" width="20" height="20" style="margin-right:8px;">
            20 mins to Lower Parel
          </li>
          
          <li style="margin-bottom:10px; display:flex; align-items:center;">
            <img src="images/icons//m3.webp" alt="Five Gardens" width="20" height="20" style="margin-right:8px;">
            5 mins from Five Gardens
          </li>
          <li style="margin-bottom:10px; display:flex; align-items:center;">
            <img src="images/icons/m4.webp" alt="Eastern Express Highway" width="20" height="20" style="margin-right:8px;">
            1 min from Eastern Express Highway
          </li>
          
          <li style="margin-bottom:10px; display:flex; align-items:center;">
            <img src="images/icons//m2.webp" alt="Shishuvan School & Don Bosco International School" width="20" height="20" style="margin-right:8px;">
            5 mins to Matunga’s cultural landmarks: Shanmukhananda Hall, Arya Bhavan, Chheda Stores & more
          </li>
        </ul>


        <p style="font-size:0.9rem; color:#555; margin-top:10px;">
          <em>Note: All distances stated in minutes are estimated travel time on 2-wheelers during normal traffic.</em>
        </p>
      </div>

      <!-- Right side map -->
      <div class="col-xl-6 col-lg-6 col-sm-11 text-dark pt-2 amenities-img">
        <img src="images/location.png" class="img-fluid data-id-btn"
          style="cursor:pointer; border:1px solid #25252560;"
          alt="Location Map"
          data-bs-target="#enquire-modal"
          data-bs-toggle="modal"
          data-bs-whatever="Request Location Details"
          data-id="Request Location" />
      </div>
    </div>
     <div id="btnmap" style="display:flex; justify-content:center; margin-top:20px;">
          <button style="width: 170px;" id="request-brochure-button" type="button"
            class="download-brochure custom-btn btn-block data-id-btn"
            data-bs-target="#enquire-modal"
            data-bs-toggle="modal"
            data-bs-whatever="Request Brochure"
            data-id="Brochure">
            <a style="color:white; text-decoration:none;" data-bs-target="#enquire-modal">
              Get Direction
            </a>
          </button>
        </div>
  </div>
</section>




            <section id="contact">
               <div class="container-fluid full-width"></div>
               <div class="container">
                  <div class="contact-inner">
                     <div class="container contact-data">
                        <div class="row">
                           <div class="col-lx-6 col-lg-6 col-sm-12 image-carousel1 ps-0 pe-0">
                              <div class="contact-video" id="vidcontainer">
                                 <img src="images/gallery/gallery5.jpg" width="100%" />
                              </div>
                           </div>
                           <div class="col-lx-6 col-lg-6 col-sm-12 form-data">
                              <h2 class="text-left ms-3 mt-3" style="font-size: 30px;color:#000;">
                                 Schedule a Site Visit
                              </h2>
                              <div class="form">
                                 <div class="row">
                                    <div class="form_inner" id="form1">
                                          <div class="form-message" style="display:none; color:green; font-weight:bold; margin-bottom:10px;"></div>
                                       <input type="text" name="name" class="form-control" placeholder="Name" id="qSenderName1" />
                                          <small class="error-message text-danger"></small>

                                       <input type="text" name="Mobile No." class="form-control phone-input" placeholder="Mobile No" id="qMobileNo1" />
                                          <small class="error-message text-danger"></small>

                                       <input type="email" name="email" class="form-control" placeholder="E-Mail Address" id="qEmailID1" />
                                          <small class="error-message text-danger"></small>
                                        <select name="configuration" class="form-control" id="qConfiguration1">
                                            <option value="">Select Configuration</option>
                                
                                                     <option value="3 BHK Flats in Matunga East">3 BHK Flats in Matunga East</option>
                                            <option value="4 BHK Flats in Matunga">4 BHK Flats in Matunga</option>

                                         </select>
                                         <input type="hidden" name="utm_source" value="" />
                                         <input type="hidden" name="utm_campaign" value="" />
                                        <div class="captcha-wrapper">
                                            <span class="captchaQuestion"></span>
                                            <input type="text" class="captchaAnswer form-control" placeholder="Enter answer" />
                                            <small class="error-message text-danger"></small>
                                        </div>


                                       <button type="button" class="btn btn-warning enquire-btn effetMoveGradient effectScale" id="SubmitQuery1">
                                       Enquire Now
                                       </button>
                                       <div class="checkbox-section">
                                          <input type="checkbox" name="" value="" checked="" />
                                          <p> I authorize company representatives to Call, SMS, Email or WhatsApp me about its products and offers. This consent overrides any registration
                                             for DNC/NDNC </p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lx-6 col-lg-6 col-sm-12 ps-0 pe-0 image-carousel m-0">
                              <!-- -->
                              <div class="contact-video">
                                 <!-- contact-video-overlay-->
                                 <img src="images/gallery4.webp" width="100%" />
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>

            <footer>
               <div class="container">
                
                  <p><b>Project Rera No.</b>P51900052415 <span>&nbsp&nbsp&nbsp<b>For details, visit:</b><a href="https://maharera.maharashtra.gov.in">https://maharera.maharashtra.gov.in</a></span></p>
                  <p id="disclaimer"> Disclaimer: The content provided on this website is for information purposes only and does not constitute an offer to avail any service. The prices mentioned are subject to change without prior notice, and the availability of properties mentioned is not guaranteed. The images displayed on the website are for representation purposes only and may not reflect the actual properties accurately. Please note that this is the official website of an authorized marketing partner. We may share data with Real Estate Regulatory Authority (RERA) registered brokers/companies for further processing as required. We may also send updates and information to the mobile number or email ID registered with us. All rights reserved. The content, design, and information on this website are protected by copyright and other intellectual property rights. Any unauthorized use or reproduction of the content may violate applicable laws. For accurate and up-to-date information regarding services, pricing, availability, and any other details, it is advisable to contact us directly through the provided contact information on this website. Thank you for visiting our website.
                  </p>
                  <p style="margin: 0px;padding-bottom: 2%;padding-top: 2%;">
                     <a href="disclaimer.html" target="_blank" style="color: #000">Disclaimer | Privacy Policy
                     </a>
                  </p>
                 
               </div>
            </footer>
            <section>
               <div class="footer-enquiryBtn d-flex d-sm-none">
                  <a class="monCall data-id-btn" id="mobPhone" href="tel:+919137829957"><em class="fa fa-phone"></em> Call</a>
                  <a id="discovery_mobile" target="_blank" class="monCall whatsappBtn data-id-btn" href="https://api.whatsapp.com/send?phone=+919137829957%20%20&amp;text=Hello,%20Looking%20for%20Lodha%20Vero%20Matunga-East%20At%20Mumbai.%20Get%20in%20touch%20with%20me%20my%20name%20is"><i class="fa fa-brands fa-WhatsApp"></i>
                  WhatsApp</a>
                  <a class="monCall data-id-btn" id="mobPhone" data-bs-target="#enquire-modal" data-bs-toggle="modal"
                     data-bs-whatever="Enquire Now" data-id="Enquire Now">Enquire Now</a>
               </div>
            </section>
         </div>
      </main>
      <section class="desktop-summary">
         <div class="og-block d-flex justify-content-between">
            <button id="right-panel-schedule-site-visit-button" class="btn data-id-btn" data-bs-target="#enquire-modal"
               data-bs-toggle="modal" data-bs-whatever="Book A Site Visit" data-id="Site Visit">
            Schedule Site Visit
            </button>
            <button class="btn"><em class="fa fa-phone"></em><a href="tel:919137829957"
               style="color:#ffff;text-decoration:none;"> +91-9137829957</a> </button>
         </div>
         <div class="form-section p-3">
            <h2 class="pb-2" style="color: #000;text-align: center; font-weight:300;" >Pre-Register here for Best Offers</h2>
            <div class="row">
               <div class="form_inner" id="form2">
                     <div class="form-message" style="display:none; color:green; font-weight:bold; margin-bottom:10px;"></div>
                  <input type="text" name="name" class="form-control" placeholder="Name" id="qSenderName2" />
                     <small class="error-message text-danger"></small>
                  <input type="text" name="Mobile No." class="form-control phone-input" placeholder="Mobile No"
                     id="qMobileNo2" />
                        <small class="error-message text-danger"></small>
                  <input type="email" name="email" class="form-control" placeholder="E-Mail Address" id="qEmailID2" />
                     <small class="error-message text-danger"></small>
                  <select name="configuration" class="form-control" id="qConfiguration2">
                        <option value="">Select Configuration</option>
                                           <option value="3 BHK Flats in Matunga East">3 BHK Flats in Matunga East</option>
                                            <option value="4 BHK Flats in Matunga">4 BHK Flats in Matunga</option>
                  </select>
                  <input type="hidden" name="utm_source" value="" />
                  <input type="hidden" name="utm_campaign" value=""/>
                  
                    <div class="captcha-wrapper">
                        <span class="captchaQuestion"></span>
                        <input type="text" class="captchaAnswer form-control" placeholder="Enter answer" />
                        <small class="error-message text-danger"></small>
                    </div>



                        
                  <button type="button" class="btn btn-warning enquire-btn effetMoveGradient effectScale btn1"
                     id="SubmitQuery2">
                  Enquire Now
                  </button>
                  <div class="checkbox-section">
                     <input type="checkbox" name="" value="" checked="" />
                     <p>
                        I authorize company representatives to Call, SMS, Email or WhatsApp me about its products and offers. This consent overrides any registration for DNC/NDNC
                     </p>
                  </div>
               </div>
            </div>

         </div>
         <!--end form-section-->
       
         <!--end call-back-section-->
      </section>
   </div>

   <div class="modal enquire-modal" data-bs-dismissable="modal" id="enquire-modal">
      <div class="modal-dialog">
         <div class="popup-images-offer">
            <!-- <div class="left-sec">
               <img src="images/SHIVAM DSK. POP UP.jpg" class="img-fluid d_sm_none">
               <img src="images/SHIVAM DSK.jpg" class="img-fluid d_sm_block">
            </div> -->
            <div class="right-sec w-100">
               <div class="modal-content" id="form3">
                  <div class="modal-header">
                     <h4 class="modal-title text-center text-white">Enquire Now</h4>
                     <button type="button" class="btn btn-md close modal-close" data-bs-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">×</span>
                     </button>
                  </div>
                  <div class="modal-body">
                     <div class="row">
                        <h4 class="text-center" style="color: #000;">Request a call back</h4>
                         <div class="form-message" style="display:none; color:green; font-weight:bold; margin-bottom:10px;"></div>
                        <div class="form_inner">
                           <input type="text" name="name" class="form-control" placeholder="Name" id="qSenderName3" />
                                                <small class="error-message text-danger"></small>

                           <input type="text" name="Mobile No." class="form-control phone-input" placeholder="Mobile No"
                           
                              id="qMobileNo3" />
                                                   <small class="error-message text-danger"></small>

                           <input type="email" name="email" class="form-control" placeholder="E-Mail Address" id="qEmailID3" />
                                                <small class="error-message text-danger"></small>

                            <select name="configuration" class="form-control" id="qConfiguration3">
                                <option value="">Select Configuration</option>
                                                                         <option value="3 BHK Flats in Matunga East">3 BHK Flats in Matunga East</option>
                                            <option value="4 BHK Flats in Matunga">4 BHK Flats in Matunga</option>

                             </select>
                             <input type="hidden" name="utm_source" value="" />
                            <input type="hidden" name="utm_campaign"  value="" />
                           
                           <div class="captcha-wrapper">
                                <span class="captchaQuestion"></span>
                                <input type="text" class="captchaAnswer form-control" placeholder="Enter answer" />
                                <small class="error-message text-danger"></small>
                            </div>


                           <button type="button" class="btn btn-warning enquire-btn effetMoveGradient effectScale" id="SubmitQuery3">
                           Enquire Now
                           </button>
                           <div class="checkbox-section">
                              <input type="checkbox" name="" value="" checked="" />
                              <p>
                                 I authorize company representatives to Call, SMS, Email or WhatsApp me about its products and offers. This consent overrides any registration for DNC/NDNC
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <script>
document.addEventListener("DOMContentLoaded", function () {
    let btn = document.getElementById("right-panel-schedule-site-visit-button");
    let modalEl = document.getElementById("enquire-modal");
    let reopenScheduled = false;

    setTimeout(() => {
        if (btn) {
            btn.click();
            console.log("Modal opened by auto-click after 5s");
        }
    }, 5000);

    modalEl.addEventListener("hidden.bs.modal", function () {
        if (!reopenScheduled) {
            reopenScheduled = true;
            setTimeout(() => {
                if (btn) {
                    btn.click();
                    console.log("Modal reopened by auto-click after 25s");
                }
            }, 20000);
        }
    });
});
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>




  <script src="js/jquery.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.min.js"></script>
  <!-- gallery JS -->
  <script src="js/slick.min.js"></script>
  <script src="js/slick-lightbox.min.js"></script>
  <script src="js/custom.js"></script>

  <script src="js/main.js"></script>

<script src="https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/intlTelInput.min.js"></script>

</body>

</html>




