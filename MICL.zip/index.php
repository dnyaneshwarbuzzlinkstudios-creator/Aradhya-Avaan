<?php
include_once __DIR__ . "/config.php";
include_once "nitropack-sdk/bootstrap.php";
?>
<!DOCTYPE html>
<html lang="en">


<head>
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WMKHRMFL');</script>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <title>Aaradhya Avaan – Luxury 3,4 & 5 BHK Residences in Tardeo | MICL</title>
  <meta name="description" content="Discover MICL’s Aaradhya Avaan in Tardeo—spacious 3, 4 & 5 BHK luxury apartments and penthouses starting from ₹8.99 Cr. Twin towers with tropical clubhouses, sea-city skyline views, and world-class amenities. Enquire today!" />
    
  <meta name="keywords" content="Aaradhya Avaan, MICL Aaradhya Avaan, Aaradhya Avaan Tardeo, Aaradhya Avaan Mumbai, Aaradhya Avaan apartments, Aaradhya Avaan floor plans, Aaradhya Avaan price, luxury flats Tardeo, 3 BHK Tardeo, 4 BHK Tardeo, luxury apartments South Mumbai, MICL projects, premium residences Mumbai" />

<link rel="icon" type="image/png" href="images/logo.png">
  <link rel="canonical" href="index-2.html" />
  <meta name="robots" content="index, follow" />
  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <link rel="stylesheet" href="css/all.min.css" />
  <link rel="stylesheet" href="css/owl.carousel.css" />
  <link rel="stylesheet" href="css/owl.theme.default.css" />
  <link rel="stylesheet" href="css/slick-theme.css" />
  <link rel="stylesheet" href="css/slick.css" />
  <link rel="stylesheet" href="css/slick-lightbox.css" />
  <link rel="stylesheet" href="css/gallery.css" />
  <link href="css/styles.css" rel="stylesheet" />
    <link href="css/main.css" rel="stylesheet" />

  <link href="css/theme.css" rel="stylesheet" />
  <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/css/intlTelInput.css" />

  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-11368350367"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-11368350367');
</script>

</head>
<body class="tvs-green">
    
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WMKHRMFL"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
   <!-- xxxxxxxxxxxx Navigator  xxxxxxxxxxxx -->
   <nav class="navbar navbar-expand-lg navbar-light fixed-top" >
      <div class="container-fluid">
         <a class="navbar-brand" href="javascript:void(0)">
            <img src="images/logo.png" class="img-fluid" alt="Logo" style="height:100%;" />
          </a>
                    <a id="logo5" class="navbar-brand" href="javascript:void(0)">
            <img src="images/logo2.png" class="img-fluid" alt="Logo" style="height:100%;" />
          </a>
          
         <div class="d-flex">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
               aria-controls="navbarNav">
            <span class="navbar-toggler-icon"></span>
            </button>
         </div>
         <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
            <ul class="navbar-nav align-items-center">
               <li class="nav-item">
                  <a class="nav-link" href="#top-section">Home</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#overview">Overview</a>
               </li>
              <li class="nav-item">
                  <a class="nav-link" href="#amenities2">Amenities</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#pricing"> Pricings </a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#floorplan"> Floor Plan</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link ml-3" href="#gallery">Gallery</a>
               </li>
                <li class="nav-item">
                  <a class="nav-link ml-3" href="#whyus">Why Us?</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#connectivity">Location</a>
               </li>
               <!-- <li class="nav-item">
                  <a class="nav-link ps4u-logo">
                  <img src="images/logo/Authorised%20AFFILIATE%20PARTNER.png" width="50">
                  </a>
                  </li> -->
            </ul>
         </div>
          <a id="logo4" class="navbar-brand">
            <img src="images/logo2.png" class="img-fluid" alt="Logo" style="height:100%;" />
          </a>
      </div>
   </nav>
   


   <!-- xxxxxxxxxxxx Navigator End xxxxxxxxxxxx -->
   <div class="main-container d-flex">
      <main class="left-section">
             <section id="top-section">
       <img class="d-block w-100" src="images/banner.webp" alt="Banner 2" width="100%"
                                 height="auto" />
   </section>
         <div class="page-wrapper">
  
            <div class="mob-form d-sm-block d-md-none d-lg-none d-none">
               <div class="call-back-section text-center pt-3 pb-3" style="border-bottom: 1px solid #ddd">
                  <h3 class="mb-0">Pre-Register here for Best Offers</h3>
               </div>
               <div class="form-section p-4">
                  <div class="row">
                     <div class="form_inner" id=" ">
                        <input type="text" name="name" class="form-control" placeholder="Name" id="qSenderName" />
                           <small class="error-message text-danger"></small>

                        <input type="text" name="Mobile No." class="form-control phone-input" placeholder="Mobile No"
                           id="qMobileNo" />
                              <small class="error-message text-danger"></small>

                        <input type="email" name="email" class="form-control" placeholder="E-Mail Address" id="qEmailID" />
                           <small class="error-message text-danger"></small>
                            <input type="hidden" name="utm_source" value="" />
                                         <input type="hidden" name="utm_campaign" value="" />
                           <div class="captcha-wrapper">
                                <span class="captchaQuestion"></span>
                                <input type="text" class="captchaAnswer form-control" placeholder="Enter answer" />
                                <small class="error-message text-danger"></small>
                            </div>


                        <button type="button" class="btn btn-warning enquire-btn effetMoveGradient effectScale btn1"
                           id="SubmitQuery">
                        Enquire Now
                        </button>
                        <div class="checkbox-section">
                           <input type="checkbox" name="" value="" checked="" />
                           <p>
                              I authorize company representatives to Call, SMS, Email or
                              WhatsApp me about its products and offers. This consent
                              overrides any registration for DNC/NDNC
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
       
            <section  id="overview">
               <div class="container">
                  <div class="row">
                     <div class="col-xl-7 col-lg-7 col-sm-12">
                        <div class="overview-data">
                           <h1 style="font-size:3rem;font-weight: 300;">Experience Vertical Grandeur in the Heart of Tardeo</h1>
                           <p class="overview-info" style="color:black;">
                                Welcome to The Halley’s of Opulence @ Aaradhya AVAAN, one of India’s tallest and
                                most innovative residential developments, redefining luxury living in South Mumbai.
                                Conceived by the renowned MICL GROUP, Aaradhya AVAAN is a beacon of vertical
                                luxury, blending opulent residences, pioneering amenities, and spectacular
                                architecture for those who demand nothing but the exceptional.


                           </p>
                           <button id="request-brochure-button" type="button"
                              class="download-brochure custom-btn btn-block data-id-btn" data-bs-target="#enquire-modal"
                              data-bs-toggle="modal" data-bs-whatever="Request Brochure" data-id="Brochure">
                           <img src="images/icons/brouchre.png" class="fa-download" />
                           Request Brochure
                           </button>
                          
                        </div>
                     </div>
                     <div class="col-xl-5 col-lg-5 col-sm-12 text-center ps-0 pe-0">
                        <img src="images/bg2.webp" width="100%" height="100%" class="data-id-btn" data-id="Project Video"
                           alt="MICL" style="border-radius: 5px;" />
                     </div>
                  </div>
<div class="row g-3 pt-3">
    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/icon1.svg" alt="Twin Towers" width="50" height="50">
            </div>
            <h4 class="feature-title">STATUESQUE TWIN TOWERS SERANO & OCEANO</h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/icon2.svg" alt="Residences" width="50" height="50">
            </div>
            <h4 class="feature-title">SPACIOUS ARRAY OF 3, 4 & 5 BED RESIDENCE</h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/icon3.svg" alt="Clubhouses" width="50" height="50">
            </div>
            <h4 class="feature-title">TWO EXCLUSIVE CLUBHOUSES</h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/icon4.svg" alt="Amenities" width="50" height="50">
            </div>
            <h4 class="feature-title">A CURATED ASSORTMENT OF AMENITIES</h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/icon5.svg" alt="Panoramic Views" width="50" height="50">
            </div>
            <h4 class="feature-title">A MULTIFARIOUS PANORAMIC VIEWS OF THE SEA & CITY</h4>
        </div>
    </div>

    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
        <div class="feature-item">
            <div class="feature-icon">
                <img src="images/icons/icon6.svg" alt="Tardeo Address" width="50" height="50">
            </div>
            <h4 class="feature-title">TARDEO, ONE OF INDIA'S MOST ELITE ADDRESS</h4>
        </div>
    </div>
</div>




               </div>
            </section>
            <!-- xxxxxxxxxxxx Overview section End  xxxxxxxxxxxx -->
            <!-- xxxxxxxxxxxx Highlight section  xxxxxxxxxxxx -->
  <div id="amenities2" class="wellbeing-container">
        <div class="wellbeing-header">
            <h1 class="wellbeing-title">Unparalleled Amenities</h1>
        </div>

        <div class="wellbeing-tabs">
            <button class="wellbeing-tab wb-active" data-wb-tab="arcade-area">18th Level – Wave House (18,000sqft)</button>
            <button class="wellbeing-tab" data-wb-tab="panorama-pavilion">34th–35th Levels – Sunrise House (17,000sqft)</button>
        </div>

        <div class="wellbeing-gallery-wrapper">
            <!-- Arcade Area Tab Content -->
            <div class="wellbeing-tab-content wb-active" id="arcade-area">
                <div class="wellbeing-gallery-slider">
                    <div class="wellbeing-slides-container">
                        <div class="wellbeing-slide">
                            <img src="images/gallery/gallery6.webp" alt="Modern Arcade Area">
                            <div class="wellbeing-slide-overlay">
                                <div class="wellbeing-slide-title">Arcade Area</div>
                                <div class="wellbeing-slide-description">State-of-the-art gaming zone with latest arcade machines and immersive entertainment</div>
                            </div>
                        </div>
                        <div class="wellbeing-slide">
                            <img src="images/gallery/gallery7.webp" alt="Gaming Lounge">
                            <div class="wellbeing-slide-overlay">
                                <div class="wellbeing-slide-title">Gaming Lounge</div>
                                <div class="wellbeing-slide-description">Premium gaming experience with cutting-edge technology and comfort</div>
                            </div>
                        </div>
                        <div class="wellbeing-slide">
                            <img src="images/gallery/gallery8.webp" alt="Entertainment Center">
                            <div class="wellbeing-slide-overlay">
                                <div class="wellbeing-slide-title">Entertainment Center</div>
                                <div class="wellbeing-slide-description">Sophisticated entertainment hub for ultimate leisure and excitement</div>
                            </div>
                        </div>
                        <div class="wellbeing-slide">
                            <img src="images/gallery/gallery9.webp" alt="VR Gaming Zone">
                            <div class="wellbeing-slide-overlay">
                                <div class="wellbeing-slide-title">VR Gaming Zone</div>
                                <div class="wellbeing-slide-description">Next-generation virtual reality gaming experience</div>
                            </div>
                        </div>
                         <div class="wellbeing-slide">
                            <img src="images/gallery/gallery16.webp" alt="Sky Lounge">
                            <div class="wellbeing-slide-overlay">
                                <div class="wellbeing-slide-title">Midlevel Shot</div>
                                <div class="wellbeing-slide-description">Captivating cityscape captured from the midlevel perspective</div>
                            </div>
                        </div>
                    </div>

                    <button class="wellbeing-nav-button wb-prev">‹</button>
                    <button class="wellbeing-nav-button wb-next">›</button>
                </div>

            </div>

            <!-- Panorama Pavilion Tab Content -->
            <div class="wellbeing-tab-content" id="panorama-pavilion">
                <div class="wellbeing-gallery-slider">
                    <div class="wellbeing-slides-container">
                        <div class="wellbeing-slide">
                            <img src="images/gallery/gallery10.webp" alt="Panorama Pavilion">
                            <div class="wellbeing-slide-overlay">
                                <div class="wellbeing-slide-title">Panorama Pavilion</div>
                                <div class="wellbeing-slide-description">Breathtaking city views from our exclusive rooftop pavilion</div>
                            </div>
                        </div>
                        <div class="wellbeing-slide">
                            <img src="images/gallery/gallery11.webp" alt="Infinity Pool">
                            <div class="wellbeing-slide-overlay">
                                <div class="wellbeing-slide-title">Infinity Pool</div>
                                <div class="wellbeing-slide-description">Stunning infinity pool overlooking the metropolitan skyline</div>
                            </div>
                        </div>
                        <div class="wellbeing-slide">
                            <img src="images/gallery/gallery12.webp" alt="Sky Terrace">
                            <div class="wellbeing-slide-overlay">
                                <div class="wellbeing-slide-title">Sky Terrace</div>
                                <div class="wellbeing-slide-description">Elegant outdoor space perfect for exclusive gatherings</div>
                            </div>
                        </div>
                        <div class="wellbeing-slide">
                            <img src="images/gallery/gallery13.webp" alt="Dining Domain">
                            <div class="wellbeing-slide-overlay">
                                <div class="wellbeing-slide-title">Dining Domain</div>
                                <div class="wellbeing-slide-description">Sophisticated dining experience with panoramic vistas</div>
                            </div>
                        </div>
                        <div class="wellbeing-slide">
                            <img src="images/gallery/gallery14.webp" alt="Sky Lounge">
                            <div class="wellbeing-slide-overlay">
                                <div class="wellbeing-slide-title">Sky Lounge</div>
                                <div class="wellbeing-slide-description">Premium lounge space with unobstructed city panoramas</div>
                            </div>
                        </div>
                        <div class="wellbeing-slide">
                            <img src="images/gallery/gallery15.webp" alt="Sky Lounge">
                            <div class="wellbeing-slide-overlay">
                                <div class="wellbeing-slide-title">Sport Lounge</div>
                                <div class="wellbeing-slide-description">Premium lounge designed for sports, recreation</div>
                            </div>
                        </div>
                    </div>

                    <button class="wellbeing-nav-button wb-prev">‹</button>
                    <button class="wellbeing-nav-button wb-next">›</button>
                </div>

              
            </div>
        </div>
    </div>
    <!-- xxxxxxxxxxxx floor plan  xxxxxxxxxxxx -->
    
    <section id="pricing">
        
        
          <div class="floorplan-main-container">
        <div class="floorplan-wrapper">
            <!-- Configuration Section -->
       <!-- Additional Pricing Information -->
                <div class="floorplan-pricing-section">
                    <h4 class="floorplan-pricing-title" style="font-size: 2.5rem;font-weight: 300;text-align: center;color: #005482;">CONFIGURATION</h4>
                    
                    <div class="floorplan-pricing-row floorplan-pricing-header">
                        <span>Configuration</span>
                        <span>Sq.Ft.</span>
                        <span>Price (INR)</span>
                        <span>Levels</span>
                    </div>
                    
                    <div class="floorplan-pricing-row">
                        <span class="floorplan-pricing-cell">3 BHK</span>
                        <span class="floorplan-pricing-cell">1,297</span>
                        <span class="floorplan-price-value">₹8.99cr++</span>
                        <span class="floorplan-pricing-cell">Below 52nd Floor</span>
                    </div>
                    
                    <div class="floorplan-pricing-row">
                        <span class="floorplan-pricing-cell">3 BHK (East)</span>
                        <span class="floorplan-pricing-cell">1,459</span>
                        <span class="floorplan-price-value">₹9.99cr++</span>
                        <span class="floorplan-pricing-cell">Below 52nd Floor</span>
                    </div>
                    
                    <div class="floorplan-pricing-row">
                        <span class="floorplan-pricing-cell">4 BHK</span>
                        <span class="floorplan-pricing-cell">2,550+</span>
                        <span class="floorplan-price-value">₹18.49cr++</span>
                        <span class="floorplan-pricing-cell">55th & above</span>
                    </div>
                    
                    <div class="floorplan-pricing-row">
                        <span class="floorplan-pricing-cell">5 BHK</span>
                        <span class="floorplan-pricing-cell">3,220+</span>
                        <span class="floorplan-price-value">₹23.49cr++</span>
                        <span class="floorplan-pricing-cell">55th & above</span>
                    </div>
                    <div class="status-container">
                        <br>
    <div class="status-title" style="font-size: 18px;font-weight: 300;color: #005482;">Serano Tower: 55% Completed</div>
    <div class="progress-bar">
      <div class="progress" style="width: 55%;"></div>
    </div>
  </div>

  <div class="status-container">
    <div class="status-title" style="font-size: 18px;font-weight: 300;color: #005482;">Oceano Tower: 50% Completed</div>
    <div class="progress-bar">
      <div class="progress" style="width: 50%;"></div>
    </div>
  </div>
                </div>
            <!-- Floor Plan Section -->
            <div id="floorplan" class="floorplan-visual-section">
                <div class="floorplan-visual-header">
                    <h4 class="floorplan-pricing-title" style="font-size: 2.5rem;font-weight: 300;text-align: center;color: #005482;">FLOOR PLAN</h4>
                </div>
                

               <div class="floorplan-image-container">
                    <div class="floorplan-image-slider">
                        <div class="floorplan-slide fp-active">
                            <img src="images/floor-plan/map1.webp" alt="Floor Plan 1" class="floorplan-img">
                        </div>
                        <div class="floorplan-slide">
                            <img src="images/floor-plan/map2.webp" alt="Floor Plan 2" class="floorplan-img">
                        </div>
                    </div>
                
                    <button class="floorplan-nav-btn floorplan-prev-btn" onclick="fpPrevSlide()">‹</button>
                    <button class="floorplan-nav-btn floorplan-next-btn" onclick="fpNextSlide()">›</button>
                </div>

            </div>
        </div>
    </div>
    </section>
    
    
<section id="section-built" class="section overflow-visible section-built">
  <div class="built-detail">
    <div class="built-img" style="margin: 0 10px;">
      <picture>
        <source media="(max-width: 1000px)" srcset="images/bg1.webp" type="image/webp">
        <source media="(max-width: 1000px)" srcset="images/bg1.webp" type="image/jpeg">
        <source srcset="images/bg1.webp" type="image/webp">
        <source srcset="images/bg1.webp" type="image/jpeg">
        <img src="images/bg1.webp" alt="Built Image" class="responsive-img" style=" width: 100%; height: auto; display: block;" />
      </picture>
    </div>
  </div>
</section>
<!-- xxxxxxxxxxxx floor plan end xxxxxxxxxxxx -->


            <!-- xxxxxxxxxxxx Gallery section  xxxxxxxxxxxx -->
            <section id="gallery">
               <div class="container wow fadeInUp">
                  <!-- data-wow-delay="0.1s" -->
                  <h1 class="text-center color-imp" style="font-size:3rem;font-weight: 300;">Project Gallery</h1>
                  <div class="content-gallery">
                     <div class="gallery js-gallery">
                               <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/gallery12.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                         <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/gallery13.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                         <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/gallery14.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                      
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/gallery3.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/gallery4.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/gallery5.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                        
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/gallery6.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                        
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/gallery7.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                        
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/gallery8.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                        
                       
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/gallery9.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/gallery10.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                        <div class="gallery-item">
                           <div class="gallery-img-holder js-gallery-popup">
                              <img src="images/gallery/gallery11.webp" alt="" class="gallery-img" />
                           </div>
                        </div>
                       
                     </div>
                  </div>
               </div>
            </section>

 <section id="unique-section-news" class="unique-section-news" style="margin:0px 10px;">
        <div class="unique-news-detail">
            <div class="unique-news-tab">
                <div class="unique-tab-details unique-section1">
                    <div class="unique-tab-list-block">
                        <ul class="unique-tab-list">
                            <li class="unique-tab active" onclick="openUniqueTab(event,'unique-tab1', 'unique-section1')">
                                <a>North</a>
                            </li>
                            <li class="unique-tab" onclick="openUniqueTab(event,'unique-tab2', 'unique-section1')">
                                <a>West</a>
                            </li>
                            <li class="unique-tab" onclick="openUniqueTab(event,'unique-tab3', 'unique-section1')">
                                <a>South</a>
                            </li>
                            <li class="unique-tab" onclick="openUniqueTab(event,'unique-tab4', 'unique-section1')">
                                <a>East</a>
                            </li>
                        </ul>
                    </div>
                    <div class="unique-tab-content">
                        <div class="unique-news-title">
                            <h1>Racecourse View</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section id="whyus" class="micl-section">
        <div class="micl-container">
            <div class="micl-header">
                <h2 class="micl-title" style="font-size:3rem;font-weight: 300;">Why Choose Aaradhya AVAAN?</h2>
            </div>
            
<div class="micl-cards-grid">
    <div class="micl-card">
        <div class="micl-card-icon">🏙️</div>
        <div class="micl-card-description">
            Among the tallest residential towers in India
        </div>
    </div>
    
    <div class="micl-card">
        <div class="micl-card-icon">🌴</div>
        <div class="micl-card-description">
            Curated tropical themed amenities on elevated levels – exclusive, innovative, and unmatched
        </div>
    </div>
    
    <div class="micl-card">
        <div class="micl-card-icon">🏡</div>
        <div class="micl-card-description">
            Generously sized, opulent homes with premium finishes and panoramic views
        </div>
    </div>
</div>

<div class="micl-cards-grid">
    <div class="micl-card">
        <div class="micl-card-icon">🚗</div>
        <div class="micl-card-description">
            Smart parking solutions with multi-level car parks & robotic tech
        </div>
    </div>
    
    <div class="micl-card">
        <div class="micl-card-icon">🏆</div>
        <div class="micl-card-description">
           MICL's legacy of iconic, trust-driven developments
        </div>
    </div>
     <div class="micl-card">
        <div class="micl-card-icon">🌏</div>
        <div class="micl-card-description">
           Land Area: 1.75 Acres
        </div>
    </div>
</div>

        </div>
    </section>


            <section id="connectivity">
               <div class="container">
                  <h2 class="text-left color-imp mb-4" style="font-size:3rem;font-weight: 300;text-align:center;">
                     Location Advantage
                  </h2>
                  
                  <div class="row pt-30">
                     <div class="col-xl-6 col-lg-6 col-sm-12 text-dark amenities-info">
                        <div class="accordion accordion-flush">
                           <div class="accordion-item accordion-data">
                              <h2 class="accordion-header">
                                 <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#Connectivity" aria-expanded="true">
                                 <img src="images/icons/school.png"> Hotels
                                 </button>
                              </h2>
                              <div id="Connectivity" class="accordion-collapse collapse show">
                                 <div class="accordion-body">
                                    <ul>
                                        <li>St. Regis - 4.8 Km</li>
                                        <li>Four Seasons - 5.1 Km</li>
                                        <li>Trident Hotel - 5.1 Km</li>
                                        <li>ITC Grand Central - 5.5 Km</li>
                                        <li>Taj Mahal Tower - 6.7 Km</li>
                                        <li>Taj Mahal Palace - 6.8 Km</li>

                                    </ul>
                                 </div>
                              </div>
                           </div>
                     
                        </div>
                         <div class="accordion accordion-flush">
                           <div class="accordion-item accordion-data">
                              <h2 class="accordion-header">
                                 <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#Connectivity1" aria-expanded="true">
                                 <img src="images/icons/road.png"> Connectivity
                                 </button>
                              </h2>
                              <div id="Connectivity1" class="accordion-collapse collapse ">
                                 <div class="accordion-body">
                                    <ul>
                                        <li>Nana Chowk - 0.5 Km</li>
                                        <li>Mumbai Central - 1.8 Km</li>
                                        <li>Bandra-Worli Sea Link - 13.2 Km</li>
                                        <li>Eastern Express Highway - 19.5 Km</li>
                                        <li>Western Express Highway - 20.7 Km</li>

                                    </ul>
                                 </div>
                              </div>
                           </div>
                     
                        </div>
                        <div class="accordion accordion-flush">
                           <div class="accordion-item accordion-data">
                              <h2 class="accordion-header">
                                 <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#Connectivity3" aria-expanded="true">
                                 <img src="images/icons/thumb-ups.png"> Business Districts
                                 </button>
                              </h2>
                              <div id="Connectivity3" class="accordion-collapse collapse ">
                                 <div class="accordion-body">
                                    <ul>
                                        <li>Ballard Estate - 4.9 Km</li>
                                        <li>Lower Parel - 5.3 Km</li>
                                        <li>Nariman Point - 5.4 Km</li>
                                        <li>Bandra Kurla Complex - 16.3 Km</li>

                                    </ul>
                                 </div>
                              </div>
                           </div>
                     
                        </div>
                         <div class="accordion accordion-flush">
                           <div class="accordion-item accordion-data">
                              <h2 class="accordion-header">
                                 <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#Connectivity2" aria-expanded="true">
                                 <img src="images/icons/healthcare.png"> Entertainment Hubs
                                 </button>
                              </h2>
                              <div id="Connectivity2" class="accordion-collapse collapse ">
                                 <div class="accordion-body">
                                    <ul>
                                        <li>Phoenix Palladium - 4.8 Km</li>
                                        <li>Kamala Mills - 5.8 Km</li>
                                        <li>Todi Mills - 6.0 Km</li>

                                    </ul>
                                 </div>
                              </div>
                           </div>
                           </div>
                           <div class="accordion accordion-flush">
                           <div class="accordion-item accordion-data">
                              <h2 class="accordion-header">
                                 <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#Connectivity6" aria-expanded="true">
                                 <img src="images/icons/healthcare.png"> Airport
                                 </button>
                              </h2>
                              <div id="Connectivity6" class="accordion-collapse collapse ">
                                 <div class="accordion-body">
                                    <ul>
                                        <li>Mumbai Domestic Airport- 18.9 Km</li>
                                        <li>Mumbai International Airport - 23.1 Km</li>

                                    </ul>
                                 </div>
                              </div>

                           </div>
                     
                        </div>
                        <div id="btnmap" style="display: flex;justify-content: center;">
                                                        <button style="width: 170px;" id="request-brochure-button" type="button"
                                 class="download-brochure custom-btn btn-block data-id-btn"
                                 data-bs-target="#enquire-modal"
                                 data-bs-toggle="modal"
                                 data-bs-whatever="Request Brochure"
                                 data-id="Brochure">
                                <a style="color: white;text-decoration: none;" href="https://goo.gl/maps/LUNYniEjZAgGPyk88" target="_blank">
                                  Get Direction <img src="images/hoverlocation.svg" class="mt-0">
                                </a>
                              </button>
                              </div>
                     </div>
                     <div class="col-xl-6 col-lg-6 col-sm-11 text-dark pt-2 amenities-img">
                        <!-- location-img-->
                        <img src="images/location1.png" class="img-fluid data-id-btn" style="cursor: pointer; border: 1px solid #25252560;" alt="" data-bs-target="#enquire-modal" data-bs-toggle="modal" data-bs-whatever="Request Location Details" data-id="Request Location" />
                     </div>
                     

                  </div>
               

               </div>
            </section>




            <section id="contact">
               <div class="container-fluid full-width"></div>
               <div class="container">
                  <div class="contact-inner">
                     <div class="container contact-data">
                        <div class="row">
                           <div class="col-lx-6 col-lg-6 col-sm-12 image-carousel1 ps-0 pe-0">
                              <div class="contact-video" id="vidcontainer">
                                 <img src="images/gallery/gallery14.webp" width="100%" />
                              </div>
                           </div>
                           <div class="col-lx-6 col-lg-6 col-sm-12 form-data">
                              <h2 class="text-left ms-3 mt-3" style="font-size: 30px;color:#005482;">
                                 Schedule a Site Visit
                              </h2>
                              <div class="form">
                                 <div class="row">
                                    <div class="form_inner" id="form1">
                                          <div class="form-message" style="display:none; color:green; font-weight:bold; margin-bottom:10px;"></div>
                                       <input type="text" name="name" class="form-control" placeholder="Name" id="qSenderName1" />
                                          <small class="error-message text-danger"></small>

                                       <input type="text" name="Mobile No." class="form-control phone-input" placeholder="Mobile No" id="qMobileNo1" />
                                          <small class="error-message text-danger"></small>

                                       <input type="email" name="email" class="form-control" placeholder="E-Mail Address" id="qEmailID1" />
                                          <small class="error-message text-danger"></small>
                                          <select name="configuration" class="form-control" id="qConfiguration1">
                                                <option value="">Select Configuration</option>
                                                <option value="3 BHK ₹8.99 Cr++">
                                                    3 BHK — ₹8.99 Cr++
                                                </option>
                                                <option value="3 BHK (East) ₹9.99 Cr++">
                                                    3 BHK (East) — ₹9.99 Cr++
                                                </option>
                                                <option value="4 BHK ₹18.49 Cr++">
                                                    4 BHK — ₹18.49 Cr++
                                                </option>
                                                <option value="5 BHK ₹23.49 Cr++">
                                                    5 BHK — ₹23.49 Cr++
                                                </option>
                                            </select>

                                        <input type="hidden" name="utm_source" value="" />
                                         <input type="hidden" name="utm_campaign" value="" />
                                      <div class="captcha-wrapper">
                                        <span class="captchaQuestion"></span>
                                        <input type="text" class="captchaAnswer form-control" placeholder="Enter answer" />
                                        <small class="error-message text-danger"></small>
                                    </div>

                                       <button type="button" class="btn btn-warning enquire-btn effetMoveGradient effectScale" id="SubmitQuery1">
                                       Enquire Now
                                       </button>
                                       <div class="checkbox-section">
                                          <input type="checkbox" name="" value="" checked="" />
                                          <p> I authorize company representatives to Call, SMS, Email or WhatsApp me about its products and offers. This consent overrides any registration
                                             for DNC/NDNC </p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lx-6 col-lg-6 col-sm-12 ps-0 pe-0 image-carousel m-0">
                              <!-- -->
                              <div class="contact-video">
                                 <!-- contact-video-overlay-->
                                 <img src="images/gallery/gallery14.webp" width="100%" />
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>

            <footer>
               <div class="container">
                
                  <p><b>Project Rera No.</b>P51900048675</p>
                  <p id="disclaimer"> Disclaimer: The content provided on this website is for information purposes only and does not constitute an offer to avail any service. The prices mentioned are subject to change without prior notice, and the availability of properties mentioned is not guaranteed. The images displayed on the website are for representation purposes only and may not reflect the actual properties accurately. Please note that this is the official website of an authorized marketing partner. We may share data with Real Estate Regulatory Authority (RERA) registered brokers/companies for further processing as required. We may also send updates and information to the mobile number or email ID registered with us. All rights reserved. The content, design, and information on this website are protected by copyright and other intellectual property rights. Any unauthorized use or reproduction of the content may violate applicable laws. For accurate and up-to-date information regarding services, pricing, availability, and any other details, it is advisable to contact us directly through the provided contact information on this website. Thank you for visiting our website.
                  </p>
                  <p style="margin: 0px;padding-bottom: 2%;padding-top: 2%;">
                     <a href="disclaimer.html" target="_blank" style="color: #000">Disclaimer | Privacy Policy
                     </a>
                  </p>
                 
               </div>
            </footer>
            <section>
               <div class="footer-enquiryBtn d-flex d-sm-none">
                  <a class="monCall data-id-btn" id="mobPhone" href="tel:+919137829957"><em class="fa fa-phone"></em> Call</a>
                  <a id="discovery_mobile" target="_blank" class="monCall whatsappBtn data-id-btn" href="https://api.whatsapp.com/send?phone=+919137829957%20%20&amp;text=Hello,%20Looking%20for%20MICL%20Aradhya-AVAAN%20Tardeo%20At%20Tardeo,%20Mumbai.%20Get%20in%20touch%20with%20me%20my%20name%20is"><i class="fa fa-brands fa-WhatsApp"></i>
                  WhatsApp</a>
                  <a class="monCall data-id-btn" id="mobPhone" data-bs-target="#enquire-modal" data-bs-toggle="modal"
                     data-bs-whatever="Enquire Now" data-id="Enquire Now">Enquire Now</a>
               </div>
            </section>
         </div>
      </main>
      <section class="desktop-summary">
         <div class="og-block d-flex justify-content-between">
            <button id="right-panel-schedule-site-visit-button" class="btn data-id-btn" data-bs-target="#enquire-modal"
               data-bs-toggle="modal" data-bs-whatever="Book A Site Visit" data-id="Site Visit">
            Schedule Site Visit
            </button>
            <button class="btn"><em class="fa fa-phone"></em><a href="tel:919137829957"
               style="color:#ffff;text-decoration:none;"> +91-9137829957</a> </button>
         </div>
         <div class="form-section p-3">
            <h2 class="pb-2" style="color: #005484;text-align: center; font-weight:300;" >Pre-Register here for Best Offers</h2>
            <div class="row">
               <div class="form_inner" id="form2">
                     <div class="form-message" style="display:none; color:green; font-weight:bold; margin-bottom:10px;"></div>
                  <input type="text" name="name" class="form-control" placeholder="Name" id="qSenderName2" />
                     <small class="error-message text-danger"></small>
                  <input type="text" name="Mobile No." class="form-control phone-input" placeholder="Mobile No"
                     id="qMobileNo2" />
                        <small class="error-message text-danger"></small>
                  <input type="email" name="email" class="form-control" placeholder="E-Mail Address" id="qEmailID2" />
                     <small class="error-message text-danger"></small>
                      <select name="configuration" class="form-control" id="qConfiguration2">
                            <option value="">Select Configuration</option>
                            <option value="3 BHK ₹8.99 Cr++">
                                3 BHK — ₹8.99 Cr++
                            </option>
                            <option value="3 BHK (East) ₹9.99 Cr++">
                                3 BHK (East) — ₹9.99 Cr++
                            </option>
                            <option value="4 BHK ₹18.49 Cr++">
                                4 BHK — ₹18.49 Cr++
                            </option>
                            <option value="5 BHK ₹23.49 Cr++">
                                5 BHK — ₹23.49 Cr++
                            </option>
                        </select>
                        <input type="hidden" name="utm_source" value="" />
                        <input type="hidden" name="utm_campaign" value="" />
                        <div class="captcha-wrapper">
                            <span class="captchaQuestion"></span>
                            <input type="text" class="captchaAnswer form-control" placeholder="Enter answer" />
                            <small class="error-message text-danger"></small>
                        </div>
                                
                  <button type="button" class="btn btn-warning enquire-btn effetMoveGradient effectScale btn1"
                     id="SubmitQuery2">
                  Enquire Now
                  </button>
                  <div class="checkbox-section">
                     <input type="checkbox" name="" value="" checked="" />
                     <p>
                        I authorize company representatives to Call, SMS, Email or WhatsApp me about its products and offers. This consent overrides any registration for DNC/NDNC
                     </p>
                  </div>
               </div>
            </div>

         </div>
         <!--end form-section-->
       
         <!--end call-back-section-->
      </section>
   </div>

   <div class="modal enquire-modal" data-bs-dismissable="modal" id="enquire-modal">
      <div class="modal-dialog">
         <div class="popup-images-offer">
            <!-- <div class="left-sec">
               <img src="images/SHIVAM DSK. POP UP.jpg" class="img-fluid d_sm_none">
               <img src="images/SHIVAM DSK.jpg" class="img-fluid d_sm_block">
            </div> -->
            <div class="right-sec w-100">
               <div class="modal-content" id="form3">
                  <div class="modal-header">
                     <h4 class="modal-title text-center">Enquire Now</h4>
                     <button type="button" class="btn btn-md close modal-close" data-bs-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">×</span>
                     </button>
                  </div>
                  <div class="modal-body">
                     <div class="row">
                        <h4 class="text-center" style="color: #005482;">MICL- Aradhya-AVAAN</h4>
                         <div class="form-message" style="display:none; color:green; font-weight:bold; margin-bottom:10px;"></div>
                        <div class="form_inner">
                           <input type="text" name="name" class="form-control" placeholder="Name" id="qSenderName3" />
                           <input type="text" name="Mobile No." class="form-control phone-input" placeholder="Mobile No"
                              id="qMobileNo3" />
                           <input type="email" name="email" class="form-control" placeholder="E-Mail Address" id="qEmailID3" />
                            <select name="configuration" class="form-control" id="qConfiguration1">
                                <option value="">Select Configuration</option>
                                <option value="3 BHK ₹8.99 Cr++">
                                    3 BHK — ₹8.99 Cr++
                                </option>
                                <option value="3 BHK (East) ₹9.99 Cr++">
                                    3 BHK (East) — ₹9.99 Cr++
                                </option>
                                <option value="4 BHK ₹18.49 Cr++">
                                    4 BHK — ₹18.49 Cr++
                                </option>
                                <option value="5 BHK ₹23.49 Cr++">
                                    5 BHK — ₹23.49 Cr++
                                </option>
                            </select>
                            <input type="hidden" name="utm_source" value="" />
                            <input type="hidden" name="utm_campaign" value="" />
                       <div class="captcha-wrapper">
                            <span class="captchaQuestion"></span>
                            <input type="text" class="captchaAnswer form-control" placeholder="Enter answer" />
                            <small class="error-message text-danger"></small>
                        </div>
                                
                           <button type="button" class="btn btn-warning enquire-btn effetMoveGradient effectScale" id="SubmitQuery3">
                           Enquire Now
                           </button></div>
                           <br>
                           <div class="checkbox-section">
                              <input type="checkbox" name="" value="" checked="" />
                              <p>
                                 I authorize company representatives to Call, SMS, Email or WhatsApp me about its products and offers. This consent overrides any registration for DNC/NDNC
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
  
<script>
document.addEventListener("DOMContentLoaded", function () {
    let btn = document.getElementById("right-panel-schedule-site-visit-button");
    let modalEl = document.getElementById("enquire-modal");
    let reopenScheduled = false;

    // First auto-click after 5s
    setTimeout(() => {
        if (btn) {
            btn.click();
            console.log("Modal opened by auto-click after 5s");
        }
    }, 5000);

    // When modal is closed → reopen after 25s (only once)
    modalEl.addEventListener("hidden.bs.modal", function () {
        if (!reopenScheduled) {
            reopenScheduled = true;
            setTimeout(() => {
                if (btn) {
                    btn.click();
                    console.log("Modal reopened by auto-click after 25s");
                }
            }, 20000);
        }
    });
});
</script>
    <script>
    (function(){
        if (window.matchMedia("(max-width: 425px)").matches) {
            Array.from(document.getElementsByClassName('d_sm_none')).forEach(function(item){
                item.parentNode.removeChild(item);
            });
        }else{
            Array.from(document.getElementsByClassName('d_sm_block')).forEach(function(item){
                item.parentNode.removeChild(item);
            });
        }
    })()
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <script src="js/jquery.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.min.js"></script>
  <!-- gallery JS -->
  <script src="js/slick.min.js"></script>
  <script src="js/slick-lightbox.min.js"></script>
  <script src="js/custom.js"></script>
 <script src="js/main.js"></script>

<script src="https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/intlTelInput.min.js"></script>




<!--Enquiries   submission -->



</body>


</html>




