
      // ---------------- UTM TRACKING ----------------
(function(){
    function getParameterByName(name) {
        name = name.replace(/[\[\]]/g, "\\$&");
        var url = window.location.href;
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return "";
        if (!results[2]) return "";
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }

    var utm_source   = getParameterByName("utm_source");
    var utm_campaign = getParameterByName("utm_campaign");
   
    if (utm_source)   localStorage.setItem("utm_source", utm_source);
    if (utm_campaign) localStorage.setItem("utm_campaign", utm_campaign);
})();

      $(document).ready(function(){
        let source   = localStorage.getItem("utm_source")   || "";
        let campaign = localStorage.getItem("utm_campaign") || "";
        
        $("input[name='utm_source']").val(source);
        $("input[name='utm_campaign']").val(campaign);


                            // Generate captcha for a given form
                            function generateCaptcha(form) {
                                let num1 = Math.floor(Math.random() * 10) + 1;
                                let num2 = Math.floor(Math.random() * 10) + 1;
                                form.data("captcha-sum", num1 + num2); // store sum inside form
                                form.find(".captchaQuestion").text(num1 + " + " + num2 + " ?");
                                form.find(".captchaAnswer").val(""); // clear old answer
                            }
                        
                            // Generate captcha for all forms on page load
                            $(".form_inner").each(function(){
                                generateCaptcha($(this));
                            });
                        
                            function submitForm(formId) {
                                let form = $(formId);
                                let name     = form.find("input[name='name']").val().trim();
                                let mobile   = form.find("input[name='Mobile No.']").val().trim();
                                let email    = form.find("input[name='email']").val().trim();
                                let configuration = form.find("select[name='configuration']").val().trim();
                        
                                let captchaAnswer = form.find(".captchaAnswer").val().trim();
                                let button = form.find("button.enquire-btn");
                                let originalText = button.text();
                                // Clear old errors
                                form.find(".error-message").text("");
                        
                                let isValid = true;
                        
                                if(name === ""){
                                    form.find("input[name='name']").next(".error-message").text("Please enter a valid name!");
                                    isValid = false;
                                }
                                if(mobile === "" || !/^[0-9]{10}$/.test(mobile)){
                                    form.find("input[name='Mobile No.']").next(".error-message").text("Enter a valid 10-digit mobile number!");
                                    isValid = false;
                                }
                                if(email === "" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){
                                    form.find("input[name='email']").next(".error-message").text("Enter a valid email address!");
                                    isValid = false;
                                }
                        
                                // ✅ Captcha validation
                                let correctSum = form.data("captcha-sum");
                                if(parseInt(captchaAnswer) !== correctSum){
                                    form.find(".captchaAnswer").next(".error-message").text("Captcha answer is incorrect!");
                                    isValid = false;
                                    generateCaptcha(form); // regenerate new captcha
                                }
                        
                                if(!isValid) return; // stop if validation fails
                            button.prop("disabled", true);
                            button.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> sumitting...');
                                // --------- AJAX REQUEST ----------
                                $.ajax({
                                    url: "save_enquiry.php",
                                    type: "POST",
                                    data: { name, mobile, configuration,email,utm_source: source,utm_campaign: campaign},
                                    success: function(response){
                                        form.find("input").val(""); // clear form
                                        generateCaptcha(form); // reset captcha
                        
                                        form.find(".form-message")
                                            .css("color","green")
                                            .text("✅ Enquiry saved successfully!")
                                            .fadeIn();
                                             button.prop("disabled", false);
                                             button.text(originalText);
                            
                                        setTimeout(function(){
                                            form.find(".form-message").fadeOut();
                                            window.location.href = "thank-you.html";
                                        }, 1000);
                                    }
                                });
                            }
                        
                            // Button clicks
                            $("#SubmitQuery1").on("click", function(){ submitForm("#form1"); });
                            $("#SubmitQuery2").on("click", function(){ submitForm("#form2"); });
                            $("#SubmitQuery3").on("click", function(){ submitForm("#form3"); });
                        
                        });    
      
    //   Unparalleled amenities-img
    
    // Luxury Amenities Interactive Script
document.addEventListener("DOMContentLoaded", () => {
  // Navigation functionality
  const navButtons = document.querySelectorAll(".luxury-nav-btn")
  const sections = document.querySelectorAll(".amenity-section")

  // Initialize first section
  showSection("wave-house")

  // Add click event listeners to navigation buttons
  navButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const target = this.getAttribute("data-target")

      // Remove active class from all buttons
      navButtons.forEach((btn) => btn.classList.remove("active"))

      // Add active class to clicked button
      this.classList.add("active")

      // Show target section with animation
      showSection(target)
    })
  })

  function showSection(targetId) {
    // Hide all sections
    sections.forEach((section) => {
      section.classList.remove("active")
    })

    // Show target section with delay for smooth transition
    setTimeout(() => {
      const targetSection = document.getElementById(targetId)
      if (targetSection) {
        targetSection.classList.add("active")

        // Trigger card animations
        animateCards(targetSection)
      }
    }, 300)
  }

  function animateCards(section) {
    const cards = section.querySelectorAll(".amenity-card")

    // Reset card animations
    cards.forEach((card, index) => {
      card.style.animation = "none"
      card.offsetHeight // Trigger reflow
      card.style.animation = `cardSlideIn 0.6s ease forwards`
      card.style.animationDelay = `${(index + 1) * 0.1}s`
    })
  }

  // Parallax effect for floating particles
  let mouseX = 0
  let mouseY = 0

  document.addEventListener("mousemove", (e) => {
    mouseX = e.clientX / window.innerWidth
    mouseY = e.clientY / window.innerHeight

    const particles = document.querySelector(".floating-particles")
    if (particles) {
      const moveX = (mouseX - 0.5) * 20
      const moveY = (mouseY - 0.5) * 20
      particles.style.transform = `translate(${moveX}px, ${moveY}px)`
    }
  })

  // Enhanced card hover effects
  const cards = document.querySelectorAll(".amenity-card")

  cards.forEach((card) => {
    card.addEventListener("mouseenter", function () {
      // Add ripple effect
      createRipple(this)

      // Enhance glow effect
      const glow = this.querySelector(".card-glow")
      if (glow) {
        glow.style.opacity = "1"
      }
    })

    card.addEventListener("mouseleave", function () {
      const glow = this.querySelector(".card-glow")
      if (glow) {
        glow.style.opacity = "0"
      }
    })

    // Add click animation
    card.addEventListener("click", function () {
      this.style.transform = "translateY(-10px) scale(0.98)"
      setTimeout(() => {
        this.style.transform = "translateY(-10px) scale(1.02)"
      }, 150)
    })
  })

  function createRipple(element) {
    const ripple = document.createElement("div")
    ripple.style.position = "absolute"
    ripple.style.borderRadius = "50%"
    ripple.style.background = "rgba(212, 175, 55, 0.3)"
    ripple.style.transform = "scale(0)"
    ripple.style.animation = "ripple 0.6s linear"
    ripple.style.left = "50%"
    ripple.style.top = "50%"
    ripple.style.width = "20px"
    ripple.style.height = "20px"
    ripple.style.marginLeft = "-10px"
    ripple.style.marginTop = "-10px"
    ripple.style.pointerEvents = "none"

    element.appendChild(ripple)

    setTimeout(() => {
      ripple.remove()
    }, 600)
  }

  // Smooth scroll to top functionality
  function scrollToTop() {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    })
  }

  // Add scroll-based animations
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = "1"
        entry.target.style.transform = "translateY(0)"
      }
    })
  }, observerOptions)

  // Observe elements for scroll animations
  const animatedElements = document.querySelectorAll(".luxury-header, .luxury-nav-container")
  animatedElements.forEach((el) => {
    el.style.opacity = "0"
    el.style.transform = "translateY(30px)"
    el.style.transition = "all 0.8s cubic-bezier(0.4, 0, 0.2, 1)"
    observer.observe(el)
  })

  // Add CSS for ripple animation
  const style = document.createElement("style")
  style.textContent = `
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
    `
  document.head.appendChild(style)

  // Performance optimization: Throttle mouse move events
  let ticking = false

  function updateParallax() {
    const particles = document.querySelector(".floating-particles")
    if (particles) {
      const moveX = (mouseX - 0.5) * 15
      const moveY = (mouseY - 0.5) * 15
      particles.style.transform = `translate(${moveX}px, ${moveY}px)`
    }
    ticking = false
  }

  document.addEventListener("mousemove", (e) => {
    mouseX = e.clientX / window.innerWidth
    mouseY = e.clientY / window.innerHeight

    if (!ticking) {
      requestAnimationFrame(updateParallax)
      ticking = true
    }
  })
})

    $(document).ready(function () {
      $(".phone-input").each(function () {
        const input = this;
        const output = $(this).siblings(".output");

        const iti = window.intlTelInput(input, {
          allowDropdown: true,
          separateDialCode: true,
          initialCountry: "In",
          utilsScript:
            "https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/utils.js",
        });

        const handleChange = () => {
          let text;
          if (input.value) {
            text = iti.isValidNumber()
              ? "Valid number! Full international format: " + iti.getNumber()
              : "Invalid number - please try again";
          } else {
            text = "Please enter a valid number";
          }
          output.empty().text(text);
        };

        // listen to "keyup", but also "change" to update when the user selects a country
        $(input).on("change keyup", handleChange);
      });
    });
 
    $(document).ready(function () {
      $(".js-gallery").slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        arrows: true,
        fade: false,
        autoplay: false,
        autoplaySpeed: 2000,
        adaptiveHeight: true,
        prevArrow:
          '<span class="gallery-arrow mod-prev"><i class="fa fa-arrow-left"></i></span>',
        nextArrow:
          '<span class="gallery-arrow mod-next"><i class="fa fa-arrow-right"></i></span>',
        responsive: [
          {
            breakpoint: 1024,
            settings: {
              centerMode: true,
              centerPadding: "20px",
              slidesToShow: 3,
            },
          },
          {
            breakpoint: 980,
            settings: {
              centerMode: true,
              centerPadding: "20px",
              slidesToShow: 2,
            },
          },
          {
            breakpoint: 480,
            settings: {
              centerMode: true,
              centerPadding: "20px",
              slidesToShow: 1,
            },
          },
        ],
      });
      $(".js-gallery").slickLightbox({
        src: "src",
        itemSelector: ".js-gallery-popup img",
        background: "rgba(0, 0, 0, .7)",
      });
    });

    document.addEventListener("DOMContentLoaded", function () {
      var navLinks = document.querySelectorAll(".navbar-nav .nav-link");
      var navbarCollapse = document.querySelector(".navbar-collapse");

      navLinks.forEach(function (link) {
        link.addEventListener("click", function () {
          if (navbarCollapse.classList.contains("show")) {
            var bsCollapse = new bootstrap.Collapse(navbarCollapse);
            bsCollapse.hide();
          }
        });
      });
    });
    
    
    
    
    
  
        class WellbeingGallery {
            constructor() {
                this.currentSlide = 0;
                this.autoPlayInterval = null;
                this.init();
            }

            init() {
                this.bindEvents();
                this.startAutoPlay();
                this.updateSlider(); // Initialize slider position
            }

            bindEvents() {
                // Tab switching
                document.querySelectorAll('.wellbeing-tab').forEach(tab => {
                    tab.addEventListener('click', (e) => this.switchTab(e.target.dataset.wbTab));
                });

                // Navigation buttons
                document.querySelectorAll('.wb-prev').forEach(btn => {
                    btn.addEventListener('click', () => this.prevSlide());
                });

                document.querySelectorAll('.wb-next').forEach(btn => {
                    btn.addEventListener('click', () => this.nextSlide());
                });

                // Pagination dots
                document.querySelectorAll('.wellbeing-pagination-dot').forEach((dot, index) => {
                    dot.addEventListener('click', () => this.goToSlide(index));
                });

                // Pause auto-play on hover
                document.querySelectorAll('.wellbeing-gallery-slider').forEach(slider => {
                    slider.addEventListener('mouseenter', () => this.stopAutoPlay());
                    slider.addEventListener('mouseleave', () => this.startAutoPlay());
                });

                // Keyboard navigation
                document.addEventListener('keydown', (e) => {
                    if (e.key === 'ArrowLeft') this.prevSlide();
                    if (e.key === 'ArrowRight') this.nextSlide();
                });

                // Touch/swipe support
                let startX = 0;
                document.querySelectorAll('.wellbeing-gallery-slider').forEach(slider => {
                    slider.addEventListener('touchstart', (e) => {
                        startX = e.touches[0].clientX;
                    });

                    slider.addEventListener('touchend', (e) => {
                        const endX = e.changedTouches[0].clientX;
                        const diff = startX - endX;
                        
                        if (Math.abs(diff) > 50) {
                            if (diff > 0) {
                                this.nextSlide();
                            } else {
                                this.prevSlide();
                            }
                        }
                    });
                });
            }

            switchTab(tabId) {
                // Update tab buttons
                document.querySelectorAll('.wellbeing-tab').forEach(tab => {
                    tab.classList.remove('wb-active');
                });
                document.querySelector(`[data-wb-tab="${tabId}"]`).classList.add('wb-active');

                // Update tab content
                document.querySelectorAll('.wellbeing-tab-content').forEach(content => {
                    content.classList.remove('wb-active');
                });
                document.getElementById(tabId).classList.add('wb-active');

                // Reset slide position
                this.currentSlide = 0;
                this.updateSlider();
                this.restartAutoPlay();
            }

            getCurrentSlider() {
                return document.querySelector('.wellbeing-tab-content.wb-active .wellbeing-slides-container');
            }

            getCurrentSlides() {
                return document.querySelectorAll('.wellbeing-tab-content.wb-active .wellbeing-slide');
            }

            getCurrentPaginationDots() {
                return document.querySelectorAll('.wellbeing-tab-content.wb-active .wellbeing-pagination-dot');
            }

            getTotalSlides() {
                return this.getCurrentSlides().length;
            }

            nextSlide() {
                const totalSlides = this.getTotalSlides();
                this.currentSlide = (this.currentSlide + 1) % totalSlides;
                this.updateSlider();
                this.restartAutoPlay();
            }

            prevSlide() {
                const totalSlides = this.getTotalSlides();
                this.currentSlide = (this.currentSlide - 1 + totalSlides) % totalSlides;
                this.updateSlider();
                this.restartAutoPlay();
            }

            goToSlide(index) {
                this.currentSlide = index;
                this.updateSlider();
                this.restartAutoPlay();
            }
updateSlider() {
    const slider = this.getCurrentSlider();
    const slides = this.getCurrentSlides();

    if (slider && slides.length > 0) {
        const totalSlides = slides.length;

        // Detect how many slides are visible at once
        const visibleSlides = Math.floor(slider.clientWidth / slides[0].clientWidth);

        // Wrap around continuously
      if (this.currentSlide > totalSlides - 2) {
            this.currentSlide = 0; // restart from first slide
        }

        if (this.currentSlide < 0) {
            this.currentSlide = totalSlides - 2; // go to last slide if reversed
        }
  


        // Each slide’s width in %
        const slideWidth = 100 / visibleSlides;
        const translateX = -(this.currentSlide * slideWidth);
        slider.style.transform = `translateX(${translateX}%)`;
    }

  


    // Update pagination dots
    this.getCurrentPaginationDots().forEach((dot, index) => {
        dot.classList.toggle('wb-active', index === this.currentSlide);
    });
}


            startAutoPlay() {
                this.stopAutoPlay();
                this.autoPlayInterval = setInterval(() => {
                    this.nextSlide();
                }, 2000);
            }

            stopAutoPlay() {
                if (this.autoPlayInterval) {
                    clearInterval(this.autoPlayInterval);
                    this.autoPlayInterval = null;
                }
            }

            restartAutoPlay() {
                this.stopAutoPlay();
                this.startAutoPlay();
            }
        }

        // Initialize gallery when DOM is loaded
        document.addEventListener('DOMContentLoaded', () => {
            new WellbeingGallery();
        });
   
        const backgroundImages = {
            'unique-tab1': 'images/news1.jpg',
            'unique-tab2': 'images/news2.jpg',
            'unique-tab3': 'images/news3.jpg',
            'unique-tab4': 'images/news4.jpg'
        };

        const titles = {
            'unique-tab1': 'Racecourse View',
            'unique-tab2': 'Arabian Sea View', 
            'unique-tab3': 'Queen\'s Necklace View',
            'unique-tab4': 'Marine View'
        };

        function openUniqueTab(evt, tabName, sectionName) {
            var i, tablinks;
            
            // Remove active class from all tabs
            tablinks = document.getElementsByClassName("unique-tab");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }
            
            // Add active class to clicked tab
            evt.currentTarget.classList.add("active");
            
            // Change background image
            const section = document.querySelector('.unique-section-news');
            section.style.backgroundImage = `url('${backgroundImages[tabName]}')`;
            
            // Update title
            const titleElement = document.querySelector('.unique-news-title h1');
            titleElement.textContent = titles[tabName];
        }
  
        document.addEventListener('DOMContentLoaded', function() {
            const avaanObserver = new IntersectionObserver((entries) => {
                entries.forEach((entry, index) => {
                    if (entry.isIntersecting) {
                        const delay = entry.target.getAttribute('data-avaan-delay') || 0;
                        setTimeout(() => {
                            entry.target.classList.add('avaan-animate');
                        }, delay);
                    }
                });
            }, {
                threshold: 0.2,
                rootMargin: '0px 0px -50px 0px'
            });

            const avaanCards = document.querySelectorAll('.avaan-feature-card');
            avaanCards.forEach(card => {
                avaanObserver.observe(card);
            });

            // Enhanced hover effects
            avaanCards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-15px) scale(1.02)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0) scale(1)';
                });
            });

            // Parallax effect for floating elements
            window.addEventListener('scroll', () => {
                const scrolled = window.pageYOffset;
                const parallax = document.querySelectorAll('.avaan-float-element');
                const speed = 0.2;
                
                parallax.forEach(element => {
                    const yPos = -(scrolled * speed);
                    element.style.transform = `translate3d(0, ${yPos}px, 0)`;
                });
            });
        });

let fpCurrentSlide = 0;
const fpSlides = document.querySelectorAll('.floorplan-slide');
const fpTotalSlides = fpSlides.length;

function fpShowSlide(index) {
    fpSlides.forEach(slide => slide.classList.remove('fp-active'));
    fpSlides[index].classList.add('fp-active');
}

function fpNextSlide() {
    fpCurrentSlide = (fpCurrentSlide + 1) % fpTotalSlides;
    fpShowSlide(fpCurrentSlide);
}

function fpPrevSlide() {
    fpCurrentSlide = (fpCurrentSlide - 1 + fpTotalSlides) % fpTotalSlides;
    fpShowSlide(fpCurrentSlide);
}

// ✅ Auto slide every 3 seconds
setInterval(fpNextSlide, 3000);

// Click functionality for price buttons (if needed)
document.querySelectorAll('.floorplan-price-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        alert('Price inquiry form would open here');
    });
});



