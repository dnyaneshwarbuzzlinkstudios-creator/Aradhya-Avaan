<?php
namespace NitroPack\SDK;

class ChallengeProcessingException extends \Exception {}
