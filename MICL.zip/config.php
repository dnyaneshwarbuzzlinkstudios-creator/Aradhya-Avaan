<?php
define("NITROPACK_HOME_URL", "https://miclaaradhyavaan.com");
define("NITROPACK_SITE_ID", "NwLsJykpUDaPgNtePWSMbnBINwspJwpg");
define("NITROPACK_SITE_SECRET", "pK2qYq7S3whAFI0pSEfjAGozylMUVrRVlQTjumEOVtJdOrqX2qE6PRZvrpPMOABm");
