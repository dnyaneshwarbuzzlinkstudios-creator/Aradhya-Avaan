<?php
$host = "localhost"; 
$user = "u581629189_dny";
$pass = "Dpawar@123"; 
$db   = "u581629189_avaan";



$conn = new mysqli($host, $user, $pass, $db);
if($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}

// Get values from POST
$name    = $_POST['name'] ?? '';
$mobile  = $_POST['mobile'] ?? '';
$email   = $_POST['email'] ?? '';
$configuration = $_POST['configuration'] ?? '';
$utmSource =$_POST['utm_source'] ?? '';
$utmcampain =$_POST['utm_campaign'] ?? '';
$ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';

// Insert into DB
$sql = "INSERT INTO enquiries (name, mobile,configuration, email,utm_source,utm_campaign) VALUES (?,?,?,?,?,?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssss", $name, $mobile,$configuration, $email,$utmSource,$utmcampain);

if($stmt->execute()){
    echo "Enquiry send successfully!";
  $googleUrl = "https://script.google.com/macros/s/AKfycbzQKOAivZJWy38VADwSwKE2GmxMEJvSLo9aJ2wjFJng_iudk4083WFAWBlmkusMZrWPIA/exec";
    $sheetData = [
        'sheet' => 'MICL-Enquiries',
        'name' => $name,
        'mobile' => $mobile,
        'email' => $email,
        'configuration' => $configuration,
        'utm_source' => $utmSource,
        'utm_campaign' => $utmcampain,
        'ip_address'=>$ipAddress
    ];

    $ch = curl_init($googleUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($sheetData));
    $response = curl_exec($ch);
    curl_close($ch);
// utkarshdsingh12
    // ✅ Send mail   utkarshdsingh12
    $to      = "Data@digiveritaz.com";
    $subject = "📩 New Enquiry from $name";

    $htmlContent = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; background:#f4f4f4; }
            .container { max-width:600px; margin:20px auto; background:#fff; padding:20px; 
                         border-radius:10px; box-shadow:0 4px 10px rgba(0,0,0,0.1); }
            h2 { color:#2c3e50; }
            .details p { font-size:15px; margin:6px 0; }
            .label { font-weight:bold; color:#555; }
            .footer { margin-top:20px; font-size:12px; color:#777; text-align:center; }
        </style>
    </head>
    <body>
        <div class='container'>
            <h2>✨ New Customer Enquiry</h2>
            <p>You have received a new enquiry. Here are the details:</p>
            <div class='details'>
                <p><span class='label'>👤 Name:</span> {$name}</p>
                <p><span class='label'>📧 Email:</span> {$email}</p>
                <p><span class='label'>📱 Mobile:</span> {$mobile}</p>
                <p><span class='label'>🏠 configuration:</span> {$configuration}</p>

            </div>
            <div class='footer'>
                This is an automated email from your website enquiry form.
            </div>
        </div>
    </body>
    </html>";

    // Headers
    $headers  = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: MICL-Aradhya Avaan Enquiry <no-reply@yourdomain.com>\r\n";

    if(mail($to, $subject, $htmlContent, $headers)){
        echo " Email notification sent!";
    } else {
        echo " Email sending failed!";
    }

} else {
    // ❌ If DB insert fails
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
